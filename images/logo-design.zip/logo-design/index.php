<!DOCTYPE html>
<html>

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="description" content="" />
	<?php include '../includes/style.php';?>
	<title>Finest & Cheap Custom Logo Design Services in USA l <?php  echo $name;?></title>
	<link rel="icon" href="assets/images/favicon.png" sizes="48x48" />
	<link href="https://fonts.googleapis.com/css?family=Encode+Sans:300,400,800" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,500,900" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/app.css">
	<link rel="stylesheet" href="assets/css/styles.css">
	<link rel="stylesheet" href="assets/css/tstyles.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" integrity="sha512-c42qTSw/wPZ3/5LBzD+Bw5f7bSF2oxou6wEb+I/lqeaKV5FDIfMvvRp772y4jcJLKuGUOpbJMdg/BTl50fJYAw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.1.9/sweetalert2.min.css" integrity="sha512-cyIcYOviYhF0bHIhzXWJQ/7xnaBuIIOecYoPZBgJHQKFPo+TOBA+BY1EnTpmM8yKDU4ZdI3UGccNGCEUdfbBqw==" crossorigin="anonymous" referrerpolicy="no-referrer" /> </head>

<body>
	<header>
		<div class="header">
			<div id="header-sroll" class="wow">
				<div class="container">
					<div class="row">
						<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
							<div class="logo">
								<a href="#"> <img style="max-width: 100%" src="assets/images/logo.png" alt="img"> </a>
							</div>
						</div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8 text-right">
							<div class="header-content">
								<div class="call-action"> <a href="tel:<?php  echo $phone;?>"><span><small><i class="fa fa-phone-square" aria-hidden="true"></i></small><?php  echo $phone;?></span></a> <span class="login_now">

                    </span> </div>
							</div>
							<div class="clearfix"></div>
							<div class="headerMenu">
								<nav class="navbar navbar-default">
									<!-- Brand and toggle get grouped for better mobile display -->
									<div class="navbar-header">
										<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
										<a class="navbar-brand" href="#"><img src="assets/images/logo.png" alt="img"> </a>
									</div>
									<!-- Collect the nav links, forms, and other content for toggling -->
									<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
										<ul class="nav navbar-nav clearfix">
											<li class="active"><a href="#home"> HOME</a></li>
											<li><a href="#who-we-are">LOGO TYPE</a></li>
											<li><a href="#portfolio">PORTFOLIO</a></li>
											<li><a href="#packages">PACKAGES</a></li>
											<li><a href="#combopackages">COMBO PACKAGES</a></li>
										</ul>
									</div>
									<!-- /.navbar-collapse -->
								</nav>
							</div>
						</div>
						<div class="col-md-2 col-xs-12 col-sm-2">
							<div class=""> <button class="btn-line-fill" data-toggle="modal" data-target="#myModal" data-name="Basic Logo Package ~ $30">GET A FREE QUOTE</button> </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<section class="floating_wrap">
		<div class="btns_wrap">
			<a href="javascript:$zopim.livechat.window.show();" class="chat_wrap" onclick=""> <i class="fa fa-comment pur-bg"></i> <span class="pur">Chat With Us</span> </a>
			<a href="tel:<?php  echo $phone;?>" class="call_wrap"> <i class="fa fa-phone pur-bg"></i> <span class="pur"><?php  echo $phone;?></span> </a>
		</div>
		<div class="float_form_box">
			<div class="floating_form">
				<div class="floating_strip">
					<div class="rotatekaro"> <a href="javascript:;" class="">Get Free Consultancy</a> </div>
				</div>
				<div class="floating_inner">
					<h3>Signup Now</h3>
					<div class="form_wrap">
						<form method="POST" class="form-get-quote" action="javascript:;" autocomplete="off">
							<div class="row">
								<div style="margin-bottom: 0px;" class="col-md-12 col-xs-12 margin-bottom-10">
									<input type="text" autocomplete="off" class="form-control" placeholder="Full Name" name="quote[name]"required="required" />
									<p class="name-status" style="color:red"></p>
								</div>
								<div style="margin-bottom: 0px;" class="col-md-12 col-xs-12 margin-bottom-10">
									<input type="email" autocomplete="off" class="form-control" placeholder="Email" name="quote[email]"  required="required" />
									<p class="email-status" style="color:red"></p>
								</div>
								<div style="margin-bottom: 0px;" class="col-md-12 col-xs-12 margin-bottom-10 ">
									<input type="text" class="form-control phoneNum" placeholder="Phone Number" name="quote[phone]" required />
									<p class="phone-status" style="color:red"></p>
								</div>
								<div style="margin-bottom: 0px;" class="col-md-12 col-xs-12 margin-bottom-20">
									<textarea class="form-control" name="quote[message]" placeholder="Talk about your project" required></textarea>
									<p class="message-status" style="color:red"></p>
								</div>
								<div style="margin-bottom: 0px;" class="col-md-12 col-xs-12 text-center">
									<div class="text-center mid-body">
										<input class="btn-fill btn-quote" type="submit" id="quoteSubmit" name="submit" value="Send Query" /> </div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="hero-services hero-subservices customlp" id="home" style="background-color: rgb(20,93,177)!important; background-size: cover!important;">
		<div class="container">
			<div class="row">
				<div class="col-lg-7 mlist hideproweb visiblebusinesslogo">
					<div class="logosslider">
						<div class="item">
							<figure> <img src="assets/images/blp1.png" alt="img"> </figure>
						</div>
					</div>
					<div class="btn-wrap"> <span style="color: #8f24ca;">Any Confusion?<a href="javascript:$zopim.livechat.window.show();" class="ctacustom" style="color:#fff"> Why not discuss your idea?</a></span> </div>
				</div>
				<div class="col-lg-5">
					<div class="formwrap mywrap">
						<h3>Signup Now & Grab  <span>50% Discount</span></h3>
						<form method="POST" class="form-get-quote" action="javascript:;" id="quoteForm" autocomplete="off">
							<div class="row">
								<div class="col-md-12 col-xs-12 margin-bottom-10">
									<input type="text" autocomplete="off" class="form-control" placeholder="Full Name" name="quote[name]" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Full Name'" required="required" />
									<div class="name-status" style="color:red"></div>
								</div>
								<div class="col-md-12 col-xs-12 margin-bottom-10">
									<input type="email" autocomplete="off" class="form-control" placeholder="Email" name="quote[email]" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" required="required" />
									<div class="email-status" style="color:red"></div>
								</div>
								<div class="col-md-12 col-xs-12 margin-bottom-10 ">
									<input type="text" class="form-control phoneNum" placeholder="Phone Number" name="quote[phone]" required />
									<div class="phone-status" style="color:red"></div>
								</div>
								<div class="col-md-12 col-xs-12 margin-bottom-20">
									<textarea class="form-control" name="quote[message]" placeholder="Talk about your project" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Project Description'" required></textarea>
									<div class="message-status" style="color:red"></div>
								</div>
								<div class="col-md-12 col-xs-12 text-center">
									<div class="text-center mid-body">
										<button style="display:none" class=" btn-fill btn-quote buttonload"><i class="fa fa-spinner fa-spin"></i>Loading</button>
										<input class="btn-fill btn-quote" type="submit" id="quoteSubmit" name="submit" value="Send Query" /> </div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="whyysec visiblecustom">
		<div class="container">
			<ul class="marginBtm">
				<li class="first wow fadeInDown" data-wow-delay="0.4s"><span class="whyysecIcon icon-1"></span> 100% Satisfaction
					<br> Guaranteed </li>
				<li class="icon-2 wow fadeInDown" data-wow-delay="0.4s"><span class="whyysecIcon icon-2"></span> Unique Design
					<br> Guarantee </li>
				<li class="icon-3 wow fadeInDown" data-wow-delay="0.4s"><span class="whyysecIcon icon-3"></span> Unlimited
					<br> Revisions </li>
				<li class="icon-4 wow fadeInDown" data-wow-delay="0.4s"><span class="whyysecIcon icon-4"></span> Award Winning
					<br> Designers </li>
				<li class="icon-5 last wow fadeInDown" data-wow-delay="0.2s"><span class="whyysecIcon icon-5"></span> 24/7 Design
					<br> Consultancy </li>
			</ul>
		</div>
	</section>
	<section class="indussec visiblecustom">
		<div class="container">
			<div class="row">
				<div class="col-lg-3">
					<div class="brandsslide">
						<p>Over 10 Years of Experience in the Online Design Industry</p>
					</div>
				</div>
				<div class="col-lg-9">
					<figure> <img class="hideproweb" src="assets/images/secimgright.jpg"> </figure>
				</div>
			</div>
		</div>
	</section>
	<section id="who-we-are">
		<div class="container">
			<div class="row top-heading_row">
				<div class="col-md-2"></div>
				<div class="col-md-8">
					<div class="section_title">
						<h3> LOGO TYPES </h3> </div>
				</div>
				<div class="col-md-2"></div>
			</div>
			<div class="row tabs_row">
				<div class="col-md-12">
					<div class="tab-custom">
						<ul class="tabbing-links">
							<li class="current" data-targetit="tabs-illustl">Illustrative Design</li>
							<li data-targetit="tabs-mascotl">Mascot</li>
							<li data-targetit="tabs-wordl">Wordmark Design</li>
							<li data-targetit="tabs-design3dl">3D Design</li>
							<li data-targetit="tabs-abstractl">Abstract Design</li>
							<li data-targetit="tabs-letterl">Letter Logo</li>
							<li data-targetit="tabs-pictoriall">Pictorial Mark</li>
						</ul>
						<div class="tabs tabs-mascotl ">
							<div class="row">
								<div class="col-md-6"> <img src="assets/images/mascot.png" class="img-responsive center-block lazy" alt="image" /> </div>
								<div class="col-md-6">
									<div class="wrapcontents">
										<h6> Mascot Logo Design</h6>
										<p> Often colorful, sometimes cartoonish, and most always fun, the mascot logo is a great way to create your very own brand spokesperson. A mascot is simply an illustrated character that represents your company. Think of them as the ambassador for your business.</p> <a href="javascript:$zopim.livechat.window.show();" class="btn-line-fill">Let's Get Started</a> </div>
								</div>
							</div>
						</div>
						<div class="tabs tabs-illustl current">
							<div class="row">
								<div class="col-md-6"> <img src="assets/images/illustrative.png" alt="image" class="img-responsive center-block lazy" /> </div>
								<div class="col-md-6">
									<div class="wrapcontents">
										<h6> Illustrative Design </h6>
										<p> If you want to create a work of art illustrative logos are the best fit as it contains intricate artwork. It will act as a trendy as well as contemporary image of your brand and keep the viewers attention longer than the traditional logo design. We at <span class="text-grad"><?php  echo $name;?></span> use latest tools and technology to create a remarkable illustrative logo for your brand. </p> <a href="javascript:$zopim.livechat.window.show();" class="btn-line-fill">Let's Get Started</a> </div>
								</div>
							</div>
						</div>
						<div class="tabs tabs-wordl">
							<div class="row">
								<div class="col-md-6"> <img src="assets/images/wordmark.png" alt="image" class="img-responsive center-block lazy" /> </div>
								<div class="col-md-6">
									<div class="wrapcontents">
										<h6> Wordmark Design </h6>
										<p> Create your professional wordmark logo with <span class="text-grad"><?php  echo $name;?></span>. It is a pure form of logo and a text-only representation of your brand – which makes it a good choice for start-ups and accelerating businesses that are seeking a static and no-hassle solution. We allow full customization to create your own wordmark logo design to enhance your brand visibility. </p> <a href="javascript:$zopim.livechat.window.show();" class="btn-line-fill">Let's Get Started</a> </div>
								</div>
							</div>
						</div>
						<div class="tabs tabs-design3dl">
							<div class="row">
								<div class="col-md-6"> <img src="assets/images/3d-logos.png" alt="image" class="img-responsive center-block lazy" /> </div>
								<div class="col-md-6">
									<div class="wrapcontents">
										<h6> 3D Design </h6>
										<p> If youre looking for a modern style logo – our 3-Dimensional logo designs will serve you best. We specialize in making 3D logos which reflects your brand in an attractive way. With our abundant 3D logo designs enjoy the rewards of attracting a large number of clients as your audience will be able to experience look and feel of your business. Ping us now and lets add some dimensions to your boring logo designs. </p> <a href="javascript:$zopim.livechat.window.show();" class="btn-line-fill">Let's Get Started</a> </div>
								</div>
							</div>
						</div>
						<div class="tabs tabs-abstractl">
							<div class="row">
								<div class="col-md-6"> <img src="assets/images/abstract.png" alt="image" class="img-responsive center-block lazy" /> </div>
								<div class="col-md-6">
									<div class="wrapcontents">
										<h6> Abstract Design </h6>
										<p> Abstract logo designs also known as smart logos is a mix of pictures, typography and shapes. A lot of organizations today use abstract logos for their businesses. They are usually used as a conceptual strategy to represent your business idea. It also allows you to exhibit different functions of your company. Join hands with <span class="text-grad"><?php  echo $name;?></span> to create your abstract logo that reflects an unclear vision of your business so that you can play safe in your business operations. </p> <a href="javascript:$zopim.livechat.window.show();" class="btn-line-fill">Let's Get Started</a> </div>
								</div>
							</div>
						</div>
						<div class="tabs tabs-letterl">
							<div class="row">
								<div class="col-md-6"> <img src="assets/images/letter.png" alt="image" class="img-responsive center-block lazy" /> </div>
								<div class="col-md-6">
									<div class="wrapcontents">
										<h6> Letter Logo Design </h6>
										<p>Letter Marks are solely typographic. They use a symbol representing the company through the use of its initials or the brands first letter. Many corporations choose to use this kind of logo as their initials can be graphically illustrated in a better manner. </p> <a href="javascript:$zopim.livechat.window.show();" class="btn-line-fill">Let's Get Started</a> </div>
								</div>
							</div>
						</div>
						<div class="tabs tabs-pictoriall">
							<div class="row">
								<div class="col-md-6"> <img src="assets/images/pictorial.png" alt="image" class="img-responsive center-block lazy" /> </div>
								<div class="col-md-6">
									<div class="wrapcontents">
										<h6> Pictorial Mark </h6>
										<p> A pictorial mark (sometimes called a brand marks or logo symbol) is an icon, or graphic-based design. A true brand mark is only an image. Because of this, it can be a tricky logo type for new companies, or those without strong brand recognition, to use. </p> <a href="javascript:$zopim.livechat.window.show();" class="btn-line-fill">Let's Get Started</a> </div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End LOGO TYPES -->
	<div class="boder-space visiblecustom" id="portfolio">
		<div class="container">
			<!-- for custom and professional logo -->
			<h3 class="ptpx-60 hideproweb">Logo Design Solutions</h3>
			<p class="text-center hideproweb">Making a great impression on the first glance is a sign of excellent customer communication.
				<br>Looking for logo designers to design logo online? Well, look no further. We’re a logo design company that
				<br> focuses on the perfect first impression.</p>
			<!-- for professional web -->
			<h3 class="ptpx-60 visibleproweb">Web Design Solutions</h3>
			<p class="text-center visibleproweb">Making a great impression on the first glance is a sign of excellent customer communication.
				<br>Looking for logo designers to design logo online? Well, look no further. We’re a logo design company that
				<br> focuses on the perfect first impression.</p>
		</div>
		<section class="mportfolio">
			<div class="container">
				<div class="row">
					<div class="lp_portslider">
						<div class="tab-custom tab-customBottom">
							<div class="row">
								<div class="col-md-3 col-xs-12 col-sm-3">
									<div class="border-box-effect">
										<a class="" data-fancybox="port" href="assets/images/logo1.jpg" tabindex="-1">
											<figure><img src="assets/images/logo1.jpg"></figure>
										</a>
									</div>
								</div>
								<div class="col-md-3 col-xs-12 col-sm-3">
									<div class="border-box-effect">
										<a class="" data-fancybox="port" href="assets/images/logo2.jpg" tabindex="-1">
											<figure><img src="assets/images/logo2.jpg"></figure>
										</a>
									</div>
								</div>
								<div class="col-md-3 col-xs-12 col-sm-3">
									<div class="border-box-effect">
										<a class="" data-fancybox="port" href="assets/images/logo3.jpg" tabindex="-1">
											<figure><img src="assets/images/logo3.jpg"></figure>
										</a>
									</div>
								</div>
								<div class="col-md-3 col-xs-12 col-sm-3">
									<div class="border-box-effect">
										<a class="" data-fancybox="port" href="assets/images/logo4.jpg" tabindex="-1">
											<figure><img src="assets/images/logo4.jpg"></figure>
										</a>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-3 col-xs-12 col-sm-3">
									<div class="border-box-effect">
										<a class="" data-fancybox="port" href="assets/images/logo5.jpg" tabindex="-1">
											<figure><img src="assets/images/logo5.jpg"></figure>
										</a>
									</div>
								</div>
								<div class="col-md-3 col-xs-12 col-sm-3">
									<div class="border-box-effect">
										<a class="" data-fancybox="port" href="assets/images/logo6.jpg" tabindex="-1">
											<figure><img src="assets/images/logo6.jpg"></figure>
										</a>
									</div>
								</div>
								<div class="col-md-3 col-xs-12 col-sm-3">
									<div class="border-box-effect">
										<a class="" data-fancybox="port" href="assets/images/logo7.jpg" tabindex="-1">
											<figure><img src="assets/images/logo7.jpg"></figure>
										</a>
									</div>
								</div>
								<div class="col-md-3 col-xs-12 col-sm-3">
									<div class="border-box-effect">
										<a class="" data-fancybox="port" href="assets/images/logo8.jpg" tabindex="-1">
											<figure><img src="assets/images/logo8.jpg"></figure>
										</a>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-3 col-xs-12 col-sm-3">
									<div class="border-box-effect">
										<a class="" data-fancybox="port" href="assets/images/logo9.jpg" tabindex="-1">
											<figure><img src="assets/images/logo9.jpg"></figure>
										</a>
									</div>
								</div>
								<div class="col-md-3 col-xs-12 col-sm-3">
									<div class="border-box-effect">
										<a class="" data-fancybox="port" href="assets/images/logo10.jpg" tabindex="-1">
											<figure><img src="assets/images/logo10.jpg"></figure>
										</a>
									</div>
								</div>
								<div class="col-md-3 col-xs-12 col-sm-3">
									<div class="border-box-effect">
										<a class="" data-fancybox="port" href="assets/images/logo11.jpg" tabindex="-1">
											<figure><img src="assets/images/logo11.jpg"></figure>
										</a>
									</div>
								</div>
								<div class="col-md-3 col-xs-12 col-sm-3">
									<div class="border-box-effect">
										<a class="" data-fancybox="port" href="assets/images/logo12.jpg" tabindex="-1">
											<figure><img src="assets/images/logo12.jpg"></figure>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
	<div class="subservice-packages section-padding ptpx-0" id="packages">
		<div class="package_slide_wrap">
			<div class="container make-left">
				<div class="row">
					<div class="col-md-12">
						<h3>Crafting Perfect Logo Packages<br>

                        for Corporations Globally

                    </h3>
						<p class="text-center">At <?php  echo $name;?>, our main agenda is to provide you with budget friendly
							<br> solutions along with an exceptional brand identity guaranteed to set you apart from your competition. </p>
						<p class="text-center max_width">We stand tall against any other online logo design company with our conceptual logo designs. From business logo or corporate logo design to mascot or 3D logo design, we make sure you get nothing but the best logo design online. Make us your first choice for custom business logo design and corporate logo design. Reach us today and talk to our logo design architects regarding your project.</p>
					</div>
				</div>
			</div>
			<div class="container">
				<section id="customer_examples" class="section section--contest_table section-padding pricing">
					<div>
						<div data-size="0">
							<div class="contest-list contest-list--scrollable">
								<div class="contest-list__item">
									<div class="contest" id="contone">
										<div class="single">
											<figure class="packico"> <img src="assets/images/basic.svg"> </figure>
											<h3>Basic Logo <br />

                                            Package

                                        </h3> <span class="old-price">$110<small></small> ONLY <i class="cut"></i></span> <span class="price">$30<small></small> </span>
											<p>Suitable for Small businesses looking for a Custom Logo.</p> <a href="javascript:;" id="clone" class="clanchor">Click Here To See More Detail</a>
											<div class="wrap">
												<ul>
													<li><i class="fa fa-check-circle-o"></i>1 Custom Logo Design Concepts</li>
													<li><i class="fa fa-check-circle-o"></i>1 Revision Rounds</li>
													<li><i class="fa fa-check-circle-o"></i>100% Satisfaction Guarantee</li>
													<li><i class="fa fa-check-circle-o"></i>100% Unique Design Guarantee</li>
													<li><i class="fa fa-check-circle-o"></i>100% Money Back Guarantee</li>
												</ul>
												<div class="clearfix order-action text-center">
													<!--  <input class="btn-line-fill" type="submit" value="ORDER NOW" tabindex="0"> -->
													<button data-toggle="modal" data-target="#myModal" class="Btnallone btn-line-fill" data-name="Basic Logo Package ~ $30">ORDER NOW</button>
												</div>
												<!--<span class="inclusive-black"><a href="">VIEW DETAILS</a> </span>-->
												<div class="actions row">
													<div class="col-md-6 col-xs-6">
														<a href="tel:<?php  echo $phone;?>" class="action-no gre clearfix"> <span><small>Share your idea?</small><?php  echo $phone;?></span></a>
													</div>
													<div class="col-md-6 col-xs-6">
														<a href="javascript:$zopim.livechat.window.show();" class="action-chat ali clearfix pull-right" tabindex="0"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
													</div>
												</div>
											</div> <a href="tel:<?php  echo $phone;?>" class="showcall" tabindex="0"> Call Now</a> </div>
									</div>
								</div>
								<div class="contest-list__item">
									<div class="contest" id="conttwo">
										<div class="single">
											<figure class="packico"> <img src="assets/images/basic.svg"> </figure>
											<h3>Beginners Logo  <br />

                                            Package

                                        </h3> <span class="old-price">$150<small></small> ONLY <i class="cut"></i></span> <span class="price">$79<small></small> </span>
											<p>For startups and small business owners.</p> <a href="javascript:;" id="cltwo" class="clanchor">Click Here To See More Detail</a>
											<div class="wrap">
												<ul>
													<li><i class="fa fa-check-circle-o"></i>5 Custom Logo Design Concepts</li>
													<li><i class="fa fa-check-circle-o"></i>FREE Icon</li>
													<li><i class="fa fa-check-circle-o"></i>FREE Grayscale Formats</li>
													<li><i class="fa fa-check-circle-o"></i>FREE Color Options</li>
													<li><i class="fa fa-check-circle-o"></i>6 Revision Rounds</li>
													<li><i class="fa fa-check-circle-o"></i>All Final Files Format (JPEG, PNG, PDF, TIFF)</li>
													<li><i class="fa fa-check-circle-o"></i>100% Ownership Rights</li>
													<li><i class="fa fa-check-circle-o"></i>100% Satisfaction Guarantee</li>
													<li><i class="fa fa-check-circle-o"></i>100% Unique Design Guarantee (No Template)</li>
													<li><i class="fa fa-check-circle-o"></i>100% Money Back Guarantee *</li>
												</ul>
												<div class="clearfix order-action">
													<button data-toggle="modal" data-target="#myModal" class="Btnallone btn-line-fill" data-name="Beginners Logo Package ~ $79">ORDER NOW</button>
												</div>
												<div class="actions row">
													<div class="col-md-6 col-xs-6">
														<a href="tel:<?php  echo $phone;?>" class="action-no gre clearfix"> <span><small>Share your idea?</small><?php  echo $phone;?></span></a>
													</div>
													<div class="col-md-6 col-xs-6">
														<a href="javascript:$zopim.livechat.window.show();" class="action-chat ali clearfix pull-right" tabindex="0"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
													</div>
												</div>
											</div> <a href="tel:<?php  echo $phone;?>" class="showcall" tabindex="0"> Call Now</a> </div>
									</div>
								</div>
								<div class="contest-list__item">
									<div class="contest" id="contthree">
										<div class="single best-seller">
											<figure class="packico"> <img src="assets/images/basic.svg"> </figure>
											<h3>Silver Logo<br />

                                            Package

                                        </h3> <span class="old-price">$230<small></small> ONLY <i class="cut"></i></span> <span class="price">$149<small></small></span>
											<p>Flexibility and Value for growing businesses.
												<br>
											</p> <a href="javascript:;" id="clthree" class="clanchor">Click Here To See More Detail</a>
											<div class="wrap">
												<ul>
													<li><i class="fa fa-check-circle-o"></i>08 Custom Logo Design Concepts</li>
													<li><i class="fa fa-check-circle-o"></i>4 Dedicated Designers</li>
													<li><i class="fa fa-check-circle-o"></i>Unlimited Revisions</li>
													<li><i class="fa fa-check-circle-o"></i>FREE Icon</li>
													<li><i class="fa fa-check-circle-o"></i>FREE Custom Stationery Design (Letterhead, Envelope, Business Card)</li>
													<li><i class="fa fa-check-circle-o"></i>FREE MS Word Letterhead</li>
													<li><i class="fa fa-check-circle-o"></i>FREE Grayscale Formats</li>
													<li><i class="fa fa-check-circle-o"></i>FREE Color Options</li>
													<li><i class="fa fa-check-circle-o"></i>FREE File Formats (JPEG, PNG, PDF, PSD, EPS, TIFF)</li>
													<li><i class="fa fa-check-circle-o"></i>100% Ownership Rights</li>
													<li><i class="fa fa-check-circle-o"></i>100% Satisfaction Guarantee</li>
													<li><i class="fa fa-check-circle-o"></i>100% Unique Design Guarantee</li>
													<li><i class="fa fa-check-circle-o"></i>100% Money Back Guarantee *</li>
												</ul>
												<div class="clearfix order-action">
													<button data-toggle="modal" data-target="#myModal" class="Btnallone btn-line-fill" data-name="Silver Logo Package ~ $149">ORDER NOW</button>
												</div>
												<!--<span class="inclusive-black"><a href="javascript:void(0);">VIEW DETAILS</a> </span>-->
												<div class="actions row">
													<div class="col-md-6 col-xs-6">
														<a href="tel:<?php  echo $phone;?>" class="action-no gre clearfix"> <span><small>Share your idea?</small><?php  echo $phone;?></span></a>
													</div>
													<div class="col-md-6 col-xs-6">
														<a href="javascript:$zopim.livechat.window.show();" class="action-chat ali clearfix pull-right" tabindex="0"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
													</div>
												</div>
											</div> <a href="tel:<?php  echo $phone;?>" class="showcall" tabindex="0"> Call Now</a> </div>
									</div>
								</div>
								<div class="contest-list__item">
									<div class="contest" id="contfour">
										<div class="single best-seller">
											<figure class="packico"> <img src="assets/images/basic.svg"> </figure>
											<h3>Gold Logo <br />

                                            package

                                        </h3> <span class="old-price">$250<small></small> ONLY <i class="cut"></i></span> <span class="price">$199<small></small></span>
											<p>Answer to all your Branding Problems</p> <a href="javascript:;" id="clfour" class="clanchor">Click Here To See More Detail</a>
											<div class="wrap">
												<ul>
													<li><i class="fa fa-check-circle-o"></i>Unlimited Custom Logo Design Concepts</li>
													<li><i class="fa fa-check-circle-o"></i>06 Dedicated Designers</li>
													<li><i class="fa fa-check-circle-o"></i>UNLIMITED Revisions</li>
													<li><i class="fa fa-check-circle-o"></i>FREE Custom Stationery Design</li>
													<li><i class="fa fa-check-circle-o"></i>FREE MS Word Letterhead</li>
													<li><i class="fa fa-check-circle-o"></i>Free Email Signature</li>
													<li><i class="fa fa-check-circle-o"></i>FREE Grayscale Formats</li>
													<li><i class="fa fa-check-circle-o"></i>FREE Color Options</li>
													<li><i class="fa fa-check-circle-o"></i>Free Invoice Design</li>
													<li><i class="fa fa-check-circle-o"></i>FREE File Formats (JPEG, PNG, PDF, PSD, EPS, TIFF)</li>
													<li><i class="fa fa-check-circle-o"></i>100% Ownership Rights</li>
													<li><i class="fa fa-check-circle-o"></i>100% Satisfaction Guarantee</li>
													<li><i class="fa fa-check-circle-o"></i>100% Unique Design Guarantee</li>
													<li><i class="fa fa-check-circle-o"></i>100% Money Back Guarantee *</li>
													<li><i class="fa fa-check-circle-o"></i>48 to 72 hours TAT</li>
												</ul>
												<div class="clearfix order-action">
													<button data-toggle="modal" data-target="#myModal" class="Btnallone btn-line-fill" data-name="Gold Logo Package ~ $199">ORDER NOW</button>
												</div>
												<!--<span class="inclusive-black"><a href="javascript:void(0);">VIEW DETAILS</a> </span>-->
												<div class="actions row">
													<div class="col-md-6 col-xs-6">
														<a href="tel:<?php  echo $phone;?>" class="action-no gre clearfix"> <span><small>Share your idea?</small><?php  echo $phone;?></span></a>
													</div>
													<div class="col-md-6 col-xs-6">
														<a href="javascript:$zopim.livechat.window.show();" class="action-chat ali clearfix pull-right" tabindex="0"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
													</div>
												</div>
											</div> <a href="tel:<?php  echo $phone;?>" class="showcall" tabindex="0"> Call Now</a> </div>
									</div>
								</div>
								<div class="contest-list__item">
									<div class="contest" id="contfive">
										<div class="single">
											<figure class="packico"> <img src="assets/images/basic.svg"> </figure>
											<h3>Platinum Logo <br />

                                            Package

                                        </h3> <span class="old-price">$330<small></small> ONLY <i class="cut"></i></span> <span class="price">$249<small></small></span>
											<p>Affordable and Unique Branding Solutions</p> <a href="javascript:;" id="clfive" class="clanchor">Click Here To See More Detail</a>
											<div class="wrap">
												<ul>
													<li><i class="fa fa-check-circle-o"></i>Unlimited Logo Concepts</li>
													<li><i class="fa fa-check-circle-o"></i>8 Dedicated Designers</li>
													<li><i class="fa fa-check-circle-o"></i>UNLIMITED Revisions</li>
													<li><i class="fa fa-check-circle-o"></i>2 Free Custom Stationery Designs (Letterhead, Envelope, Business Card, Contract Cover Page Design)</li>
													<li><i class="fa fa-check-circle-o"></i>2 Sided Flyer (OR) Bi-Fold Brochure Design</li>
													<li><i class="fa fa-check-circle-o"></i>FREE MS Word Letterhead</li>
													<li><i class="fa fa-check-circle-o"></i>Free Email Signature</li>
													<li><i class="fa fa-check-circle-o"></i>FREE Invoice Design</li>
													<li><i class="fa fa-check-circle-o"></i>FREE Fax Template</li>
													<li><i class="fa fa-check-circle-o"></i>All Final File Format (AI, PSD, EPS, PNG, GIF, JPG, PDF)</li>
													<li><i class="fa fa-check-circle-o"></i>100% Ownership Rights</li>
													<li><i class="fa fa-check-circle-o"></i>100% Satisfaction Guarantee</li>
													<li><i class="fa fa-check-circle-o"></i>100% Unique Design Guarantee</li>
													<li><i class="fa fa-check-circle-o"></i>100% Money Back Guarantee *</li>
												</ul>
												<div class="clearfix order-action">
													<button data-toggle="modal" data-target="#myModal" class="Btnallone btn-line-fill" data-name="Platinum Logo Package ~ $249">ORDER NOW</button>
												</div>
												<!--<span class="inclusive-black"><a href="javascript:void(0);">VIEW DETAILS</a> </span>-->
												<div class="actions row">
													<div class="col-md-6 col-xs-6">
														<a href="tel:<?php  echo $phone;?>" class="action-no gre clearfix"> <span><small>Share your idea?</small><?php  echo $phone;?></span></a>
													</div>
													<div class="col-md-6 col-xs-6">
														<a href="javascript:$zopim.livechat.window.show();" class="action-chat ali clearfix pull-right" tabindex="0"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
													</div>
												</div>
											</div> <a href="tel:<?php  echo $phone;?>" class="showcall" tabindex="0"> Call Now</a> </div>
									</div>
								</div>
								<div class="contest-list__item">
									<div class="contest" id="contsix">
										<div class="single ">
											<figure class="packico"> <img src="assets/images/basic.svg"> </figure>
											<h3>Elite Logo <br />

                                            Package

                                        </h3> <span class="old-price">$1000<small></small> ONLY <i class="cut"></i></span> <span class="price">$349<small></small></span>
											<p>Your One-Stop Branding Solution</p> <a href="javascript:;" id="clsix" class="clanchor">Click Here To See More Detail</a>
											<div class="wrap">
												<ul>
													<li><i class="fa fa-check-circle-o"></i>Unlimited Logo Concepts</li>
													<li><i class="fa fa-check-circle-o"></i>8 Dedicated Designers</li>
													<li><i class="fa fa-check-circle-o"></i>UNLIMITED Revisions</li>
													<li><i class="fa fa-check-circle-o"></i>UNLIMITED Revisions</li>
													<li><i class="fa fa-check-circle-o"></i>FREE Custom Stationery Design</li>
													<li><i class="fa fa-check-circle-o"></i>Double Sided Brochure OR Flyer Design</li>
													<li><i class="fa fa-check-circle-o"></i>FREE MS Word Letterhead</li>
													<li><i class="fa fa-check-circle-o"></i>Free Email Signature</li>
													<li><i class="fa fa-check-circle-o"></i>Social Media Banner Designs</li>
													<li><i class="fa fa-check-circle-o"></i>48 Hours Turnaround Time</li>
													<li><i class="fa fa-check-circle-o"></i>FREE Icon Design</li>
													<li><i class="fa fa-check-circle-o"></i>FREE Grayscale Format</li>
													<li><i class="fa fa-check-circle-o"></i>FREE Color Options</li>
													<li><i class="fa fa-check-circle-o"></i>FREE File Formats (PSD, PDF, AI, JPEG, PNG)</li>
													<li><i class="fa fa-check-circle-o"></i>FREE Vector Files</li>
													<li><i class="fa fa-check-circle-o"></i>100% Ownership Rights</li>
													<li><i class="fa fa-check-circle-o"></i>100% Satisfaction Guarantee</li>
													<li><i class="fa fa-check-circle-o"></i>100% Unique Design Guarantee</li>
													<li><i class="fa fa-check-circle-o"></i>100% Money Back Guarantee *</li>
												</ul>
												<div class="clearfix order-action">
													<button data-toggle="modal" data-target="#myModal" class="Btnallone btn-line-fill" data-name="Elite Logo Package ~ $349">ORDER NOW</button>
												</div>
												<!--<span class="inclusive-black"><a href="javascript:void(0);">VIEW DETAILS</a> </span>-->
												<div class="actions row">
													<div class="col-md-6 col-xs-6">
														<a href="tel:<?php  echo $phone;?>" class="action-no gre clearfix"> <span><small>Share your idea?</small><?php  echo $phone;?></span></a>
													</div>
													<div class="col-md-6 col-xs-6">
														<a href="javascript:$zopim.livechat.window.show();" class="action-chat ali clearfix pull-right" tabindex="0"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
													</div>
												</div>
											</div> <a href="tel:<?php  echo $phone;?>" class="showcall" tabindex="0"> Call Now</a> </div>
									</div>
								</div>
								<div class="contest-list__item">
									<div class="contest" id="contseven">
										<div class="single">
											<figure class="packico"> <img src="assets/images/basic.svg"> </figure>
											<h3>3D Logo Design<br />

                                            Package

                                        </h3> <span class="old-price">$1130<small></small> ONLY <i class="cut"></i></span> <span class="price">$339<small></small></span>
											<p style="min-width: 282px;"></p> <a href="javascript:;" id="clseven" class="clanchor">Click Here To See More Detail</a>
											<div class="wrap">
												<ul>
													<li> <i class="fa fa-check-circle-o"></i>3 Unique 3D Logo Concepts</li>
													<li> <i class="fa fa-check-circle-o"></i>Light Effects and VFX</li>
													<li> <i class="fa fa-check-circle-o"></i>Fully Rendered</li>
													<li> <i class="fa fa-check-circle-o"></i>Multiple 3D Angles</li>
													<li> <i class="fa fa-check-circle-o"></i>By 3 Award Winning Designers</li>
													<li> <i class="fa fa-check-circle-o"></i>UNLIMITED Revisions</li>
													<li> <i class="fa fa-check-circle-o"></i>100% Ownership Rights</li>
													<li> <i class="fa fa-check-circle-o"></i>100% Satisfaction Guarantee</li>
													<li> <i class="fa fa-check-circle-o"></i>100% Unique Design Guarantee</li>
													<li> <i class="fa fa-check-circle-o"></i>100% Money Back Guarantee</li>
												</ul>
												<div class="clearfix order-action">
													<button data-toggle="modal" data-target="#myModal" class="Btnallone btn-line-fill" data-name="3D Logo Design Package ~ $399">ORDER NOW</button>
												</div>
												<!--<span class="inclusive-black"><a href="javascript:void(0);">VIEW DETAILS</a> </span>-->
												<div class="actions row">
													<div class="col-md-6 col-xs-6">
														<a href="tel:<?php  echo $phone;?>" class="action-no gre clearfix"> <span><small>Share your idea?</small><?php  echo $phone;?></span></a>
													</div>
													<div class="col-md-6 col-xs-6">
														<a href="javascript:$zopim.livechat.window.show();" class="action-chat ali clearfix pull-right" tabindex="0"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
													</div>
												</div>
											</div> <a href="tel:<?php  echo $phone;?>" class="showcall" tabindex="0"> Call Now</a> </div>
									</div>
								</div>
								<div class="contest-list__item ">
									<div class="contest" id="conteleven">
										<div class="single">
											<figure class="packico"> <img src="assets/images/basic.svg"> </figure>
											<h3>Professional Mascot <br />

                                            Logo Package

                                        </h3> <span class="old-price">$1160<small></small> ONLY <i class="cut"></i></span> <span class="price">$349<small></small></span>
											<p style="min-width: 282px;"></p> <a href="javascript:;" id="cleleven" class="clanchor">Click Here To See More Detail</a>
											<div class="wrap">
												<ul>
													<li><i class="fa fa-check-circle-o"></i>4 Logo Design Concepts</li>
													<li><i class="fa fa-check-circle-o"></i>By 4 Designers</li>
													<li><i class="fa fa-check-circle-o"></i>UNLIMITED Revisions</li>
													<li><i class="fa fa-check-circle-o"></i>100% Ownership Rights</li>
													<li><i class="fa fa-check-circle-o"></i>100% Satisfaction Guarantee</li>
													<li><i class="fa fa-check-circle-o"></i>100% Unique Design Guarantee</li>
													<li><i class="fa fa-check-circle-o"></i>100% Money Back Guarantee *</li>
												</ul>
												<div class="clearfix order-action">
													<button data-toggle="modal" data-target="#myModal" class="Btnallone btn-line-fill" data-name="Professional Mascot Logo Package ~ $349">ORDER NOW</button>
												</div>
												<!--<span class="inclusive-black"><a href="javascript:void(0);">VIEW DETAILS</a> </span>-->
												<div class="actions row">
													<div class="col-md-6 col-xs-6">
														<a href="tel:<?php  echo $phone;?>" class="action-no gre clearfix"> <span><small>Share your idea?</small><?php  echo $phone;?></span></a>
													</div>
													<div class="col-md-6 col-xs-6">
														<a href="javascript:$zopim.livechat.window.show();" class="action-chat ali clearfix pull-right" tabindex="0"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
													</div>
												</div>
											</div> <a href="tel:<?php  echo $phone;?>" class="showcall" tabindex="0"> Call Now</a> </div>
									</div>
								</div>
								<div class="contest-list__item ">
									<div class="contest" id="contten">
										<div class="single">
											<figure class="packico"> <img src="assets/images/basic.svg"> </figure>
											<h3>Basic Illustrative <br />

                                            Logo Package

                                        </h3> <span class="old-price">$430<small></small> ONLY <i class="cut"></i></span> <span class="price">$129<small></small> </span>
											<p style="min-width: 282px;"></p> <a href="javascript:;" id="clten" class="clanchor">Click Here To See More Detail</a>
											<div class="wrap">
												<ul>
													<li><i class="fa fa-check-circle-o"></i>One Custom Logo Design Concepts</li>
													<li><i class="fa fa-check-circle-o"></i>By 2 Designers</li>
													<li><i class="fa fa-check-circle-o"></i>UNLIMITED Revisions</li>
													<li><i class="fa fa-check-circle-o"></i>All Final Files Format (AI, PSD, EPS, PNG, GIF, JPG, PDF)</li>
													<li><i class="fa fa-check-circle-o"></i>100% Ownership Rights</li>
													<li><i class="fa fa-check-circle-o"></i>100% Satisfaction Guarantee</li>
													<li><i class="fa fa-check-circle-o"></i>100% Unique Design Guarantee</li>
													<li><i class="fa fa-check-circle-o"></i>100% Money Back Guarantee *</li>
												</ul>
												<div class="clearfix order-action">
													<button data-toggle="modal" data-target="#myModal" class="Btnallone btn-line-fill" data-name="Basic Illustrative Logo Package ~ $129">ORDER NOW</button>
												</div>
												<!--<span class="inclusive-black"><a href="javascript:void(0);">VIEW DETAILS</a> </span>-->
												<div class="actions row">
													<div class="col-md-6 col-xs-6">
														<a href="tel:<?php  echo $phone;?>" class="action-no gre clearfix"> <span><small>Share your idea?</small><?php  echo $phone;?></span></a>
													</div>
													<div class="col-md-6 col-xs-6">
														<a href="javascript:$zopim.livechat.window.show();" class="action-chat ali clearfix pull-right" tabindex="0"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
													</div>
												</div>
											</div> <a href="tel:<?php  echo $phone;?>" class="showcall" tabindex="0"> Call Now</a> </div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>
			</div>
		</div>
	</div>
	<div class="contest-list__item fullwidth" id="combopackages">
		<div class="container">
			<div class="doublewrap">
				<figure class="left"> <img src="assets/images/basic.svg" style=" width: 80px; "> </figure>
				<figure class="right"> <img src="assets/images/basic.svg" style=" width: 80px; "> </figure>
				<h6>COMBO PACKAGE</h6>
				<h3>GROWTH SEEKER PACKAGE</h3>
				<div class="row">
					<ul class="col-lg-4 jack">
						<li class="heading">Logo Design</li>
						<li>5 Custom Logo Design Concepts</li>
						<li>By 2 Designers</li>
						<li>Icon Design</li>
						<li>File Formats (PSD, PDF, AI, JPEG, PNG)</li>
						<li class="heading">Stationary</li>
						<li>Business Card, Letterhead, Envelope, Fax Template</li>
						<li>MS Word Letterhead</li>
						<li class="heading">Social Media</li>
						<li>Facebook Page Design</li>
						<li>Twitter Page Design</li>
					</ul>
					<ul class="col-lg-4 jack">
						<li class="heading">&nbsp;</li>
						<li>YouTube Page Design</li>
						<li>Google+ Page Design</li>
						<li>Instagram Page Design </li>
						<li>All Final File Formats</li>
						<li class="heading">Website</li>
						<li>5 Pages Website</li>
						<li>CMS / Admin Panel</li>
						<li>Mobile Responsive</li>
						<li>Team of Expert Designers & Developers</li>
						<li>8 Stock images</li>
						<li>5 Banner Designs</li>
					</ul>
					<ul class="col-lg-4 jack">
						<li class="heading">&nbsp;</li>
						<li>jQuery Sliders</li>
						<li>Free Google Friendly Sitemap</li>
						<li>Complete W3C Certified HTML</li>
						<li>Complete Deployment</li>
						<li class="heading">Value Added Services</li>
						<li>All Final File Formats</li>
						<li>Dedicated Account Manager</li>
						<li>100% Ownership Rights</li>
						<li>100% Satisfaction Guarantee</li>
						<li>100% Unique Design Guarantee</li>
						<li>100% Money Back Guarantee</li>
					</ul>
				</div>
				<div class="row">
					<div class="col-lg-7">
						<div class="chatt">
							<div class="actions">
								<a href="tel:<?php  echo $phone;?>" class="action-no"> <i class="fa fa-phone-square"></i> <?php  echo $phone;?></a>
								<a href="javascript:$zopim.livechat.window.show();" class="action-chat"> <i class="fa fa-wechat"></i> LIVE CHAT</a>
							</div>
							<h2 style="color: black;">For more information speak with us</h2> </div>
					</div>
					<div class="col-lg-5">
						<div class="priccc"> <span class="old-price">$1,798.00<small></small><i class="cut"></i></span> <span class="price">$899.00<small></small></span> </div>
						<div class="wrapk">
							<!--<input class="btn btn-green" type="submit"  value="ORDER NOW" />-->
							<button data-toggle="modal" data-target="#myModal" class="Btnallone btn-line-fill" data-name="COMBO PACKAGE ~ $899">ORDER NOW</button>
							<p class="nichaywala">20% more OFF on Next Order</p>
							<!--<a href="javascript:void(0);" class="view-detail">VIEW DETAILS</a>--></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="boder-space hidecustom">
		<div class="package_slide_wrap visibleappdesign adpadtop-60">
			<div class="container make-left">
				<div class="row">
					<div class="col-md-12">
						<h3>Design &amp; Develop The Next Big Mobile Application </h3>
						<p class="text-center max_width">We always emphasize simplifying processes in order to take an optimum route that inevitably results in a lean production phase with our sights ultimately set on robust structure and scalability. With impressive results envisioned from the start, we work backwards from this point in order to ensure we trace out all essentials as well as other components we may need to add as deemed suitable.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<section class="brand-logos">
		<div class="container contant">
			<h2>Our Work Process</h2>
			<div class="col-md-3 col-sm-6 col-xs-12 process-box"> 
				<h5>Design Brief</h5> </div>
			<div class="col-md-3 col-sm-6 col-xs-12 process-box"> 
				<h5>Brainstorming</h5> </div>
			<div class="col-md-3 col-sm-6 col-xs-12 process-box"> 
				<h5>Planning</h5> </div>
			<div class="col-md-3 col-sm-6 col-xs-12 process-box"> 
				<h5>Designing</h5> </div>
			<div class="col-md-3 col-sm-6 col-xs-12 process-box">
				<h5>Deploy</h5> </div>
		</div>
	</section>
	<section class="section-padding count">
		<div class="container wow">
			<div class="row">
				<div class="col-md-12">
					<h3 class="text-center wow fadeInDown" data-wow-delay="0.2s">Numbers That Move Mountains</h3>
					<p class="text-center wow fadeInDown" data-wow-delay="0.4s">When we say we aim for the best, we definitely mean we set it as our goal to make a change and move mountains with the projects we do.
						<br>Reach us today with your project goals and join hands to design excellence. </p>
				</div>
			</div>
			<div class="book-area"> </div>
			<div class="count-area statistics">
				<div class="row text-center statistics-inner">
					<div class="col-xs-3 col-sm-3 col-md-3 stat clearfix" data-count="5678"> <span class="number">3410</span>
						<h6 class="count-title">Satisfied Customer</h6> </div>
					<div class="col-xs-3 col-sm-3 col-md-3 stat clearfix" data-count="9892"> <span class="number">7281</span>
						<h6 class="count-title">Projects Completed</h6> </div>
					<div class="col-xs-3 col-sm-3 col-md-3 stat clearfix" data-count="15890"> <span class="number">1791</span>
						<h6 class="count-title">Launched Products</h6> </div>
					<div class="col-xs-3 col-sm-3 col-md-3 stat clearfix" data-count="1015"> <span class="number">995</span>
						<h6 class="count-title">Daily Visits</h6> </div>
				</div>
			</div>
		</div>
	</section>
	<section class="section-padding testimonials" id="testimonials">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h3 class="wow fadeInDown" data-wow-delay="0.2s">Testimonials</h3>
					<p class="wow fadeInDown text-center main" data-wow-delay="0.4s">What our customers say about us</p>
				</div>
			</div>
			<div class="">
				<div>
					<div class="row set-height">
						<div class="col-md-4">
							<div class="testi_box testiBoxHeight boxPadding1">
								<div class="testiImg"><img src="assets/images/testiImg.png"></div>
								<div class="testiText">
									<h3 class="paddinfLeft"><?php  echo $name;?> provided me with just what I needed.</h3>
									<p class="paddinfLeft"> A great website that focuses on my products and provides friendly user interface.</p> <span class="testi_owner paddinfLeft">Jessica Williams, Owner</span> <span class="stars paddinfLeft">

                                    <i class="fa fa-star" aria-hidden="true"></i>

                                    <i class="fa fa-star" aria-hidden="true"></i>

                                    <i class="fa fa-star" aria-hidden="true"></i>

                                    <i class="fa fa-star" aria-hidden="true"></i>

                                    <i class="fa fa-star" aria-hidden="true"></i>

                                </span> </div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="testi_box testiBoxHeight boxPadding2">
								<div class="testiImg"><img src="assets/images/testiImg2.png"></div>
								<div class="testiText">
									<h3 class="paddinfLeft">Provided an identity that has impressed all our customers. </h3>
									<p class="paddinfLeft">The logo speaks volume and have received numerous appreciations for it. The impact is profound and we are enjoying the success.</p> <span class="testi_owner paddinfLeft">Jeffery-Houston, TX</span> <span class="stars paddinfLeft">

                    <i class="fa fa-star" aria-hidden="true"></i>

                    <i class="fa fa-star" aria-hidden="true"></i>

                    <i class="fa fa-star" aria-hidden="true"></i>

                    <i class="fa fa-star" aria-hidden="true"></i>

                    <i class="fa fa-star-half-o" aria-hidden="true"></i>

                    </span> </div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="testi_box testiBoxHeight boxPadding3">
								<div class="testiImg"><img src="assets/images/testiImg3.png"></div>
								<div class="testiText">
									<h3 class="paddinfLeft">A job really well done by the <?php  echo $name;?> team.</h3>
									<p class="paddinfLeft">What I liked most was the professionalism right from the moment design consultant contacted us till project delivery. We at Quick Check love the new logo and are excited with our new identity</p> <span class="testi_owner paddinfLeft">Linda J Schroeder</span> <span class="stars paddinfLeft">

                    <i class="fa fa-star" aria-hidden="true"></i>

                    <i class="fa fa-star" aria-hidden="true"></i>

                    <i class="fa fa-star" aria-hidden="true"></i>

                    <i class="fa fa-star" aria-hidden="true"></i>

                    <i class="fa fa-star-half-o" aria-hidden="true"></i>

                    </span> </div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="section-padding gray_bg get_quote" id="getaQuote">
		<div class="container">
			<div class="row">
				<div class="col-md-push-2 col-md-8 col-xs-12">
					<h3 class="text-center">Get Free Consultancy</h3>
					<p class="text-center grey">If you are interested in speaking with <?php  echo $name;?> about an upcoming project, there are a number of ways we can make that happen. Filling out the form would help us get the right person in touch with you, or you could give us a call.</p>
					<form action="javascript:;" method="POST" class="form-get-quote" id="quoteFormBottom" autocomplete="off">
						<div class="row">
							<div class="col-xs-12 col-sm-6 col-md-6 margin-bottom-20 field-mergedright">
								<input type="text" autocomplete="off" class="form-control" placeholder="Full Name" name="quote[name]" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Full Name'" required="required" />
								<div class="name-status" style="color:red"></div>
							</div>
							<div class="col-xs-12 col-sm-6 col-md-6 margin-bottom-20 field-mergedleft">
								<input type="email" autocomplete="off" class="form-control" placeholder="Email" name="quote[email]" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" required="required" />
								<div class="email-status" style="color:red"></div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 margin-bottom-20 field-mergedright">
								<input type="text" class="form-control phoneNum" placeholder="Phone Number" name="quote[phone]"  required />
								<div class="phone-status" style="color:red"></div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 margin-bottom-20">
								<textarea class="form-control" name="quote[message]" placeholder="Talk about your project" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Project Description'" required="required"></textarea>
								<div class="message-status" style="color:red"></div>
							</div>
							<!--<div class="col-xs-12 col-sm-6 col-md-6 margin-bottom-20 field-mergedleft">-->
							<!--	<input class="checkbx-btn form-control" style="height: auto;margin: 2px 0 0 6px;vertical-align: top;" type="checkbox" autocomplete="off" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Country'" required="required" />-->
							<!--	<p class="checkbx-btnpara" style="display: inline-block; padding: 0; margin: -10px 0 0 8px; font-size: 14px;">Please hit the check box to confirm your request</p>-->
							<!--</div>-->
							<div class="col-md-12 col-xs-12 margin-bottom-20 field-mergedleft mid-body">
								<div class="clearfix"> </div>
								<div class="text-center">
									<input class="btn-fill btn-quote" style="padding: 18px 140px;font-size: 15px;" type="submit" id="quoteSubmit" name="submit" value="CONTACT OUR TEAM" /> </div>
							</div>
						</div>
						</form>
				</div>
				<!-- end col-md-6 -->
			</div>
			<!-- end row -->
		</div>
		<!-- end container -->
	</section>
	<section class="press_logos">
		<div class="container">
			<div class="pressBox"><img src="assets/images/press_logos.png" alt="Logo"></div>
		</div>
	</section>
	<footer style="background: #1758ce;">
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-3 col-xs-12">
					<h6>Quick Links</h6>
					<ul>
						<li><a style="color: white;line-height: 18px;" href="javascript:;">Branding</a></li>
						<li><a style="color: white;line-height: 18px;" href="javascript:;">Web Development</a></li>
						<li><a style="color: white;line-height: 18px;" href="javascript:;">Mobile App Development</a></li>
						<li><a style="color: white;line-height: 18px;" href="javascript:;">Explainer Videos</a></li>
						<li><a style="color: white;line-height: 18px;" href="javascript:;">Marketing</a></li>
						<li><a style="color: white;line-height: 18px;" href="javascript:;">Ecommerce</a></li>
						<li><a style="color: white;line-height: 18px;" href="javascript:;">Magento</a></li>
						<li><a style="color: white;line-height: 18px;" href="javascript:;">Shopify</a></li>
						<li><a style="color: white;line-height: 18px;" href="javascript:;">Wordpress</a></li>
					</ul>
				</div>
				<div class="col-md-3 col-sm-3 col-xs-12">
					<h6>Satisfaction &amp; Guarantee</h6>
					<a href="javascript:;"> <img alt="trustpilot" src="assets/images/fstars-footer.png"> </a>
				</div>
				<div class="col-md-3 col-sm-3 col-xs-12">
					<h6>Follow Us</h6>
					<p style="color: white;line-height: 18px;">Get social with us and get update
						<br>and latest offers.</p>
					<ul class="follow">
						<li>
							<a href="javascript:;" class="tw_icon"></a>
						</li>
						<li>
							<a href="javascript:;" class="fb_icon"></a>
						</li>
						<li>
							<a href="javascript:;" class="insta_icon"></a>
						</li>
					</ul>
					<hr>
					<div class="cardsBox"><img alt="cards" src="assets/images/certification.png"></div>
				</div>
				<div class="col-md-3 col-sm-3 col-xs-12">
					<h6><?php  echo $name;?></h6>
					<div class="contactInfo"> <address>
                        <p style="color: white;line-height: 18px;" ><?php  echo $address;?></p>
                        <a style="color: white;line-height: 18px;" href="tel:<?php  echo $phone;?>"><?php  echo $phone;?></a> | <a style="color: white;line-height: 18px;" href="mailto:<?php  echo $email;?>"><span class="__cf_email__" ><?php  echo $email;?></span></a>
                    </address>
						<hr> </div>
					<div class="paymentCards"> <img alt="cards" src="assets/images/cards.png">
						<br>
						<br> <img alt="Credit Card" src="assets/images/credit_card_img.png"> </div>
				</div>
			</div>
		</div>
		<div class="copyBox">
			<div class="container">
				<div class="row">
					<div class="col-md-2"> </div>
					<div class="col-md-4"> <a style="color: white" href="https://designflit.com/privacy-policy.php">Privacy Policy</a> <span>|</span> <a style="color: white" href="https://designflit.com/terms-conditions.php">Terms &amp;Conditions</a> </div>
					<div class="col-md-4">
						<p style="color: white">All rights reserved. <a href="/index.php" style="color: #fffffa;"><?php  echo $name;?></a></p>
					</div>
				</div>
			</div>
		</div>
		<div class="disclaimerBox">
			<div class="container">
				<div class="disclaimer_txt">
					<p><strong>Disclaimer:</strong> Logo, name and graphic representation of <?php  echo $name;?> and its products and services are trademarks of <?php  echo $name;?>. All other company names, trademarks and logos mentioned on this website are the property of their respective owners and do not represent or imply endorsement, sponsorship or recommendation by <?php  echo $name;?> and constitute or imply endorsement, sponsorship or recommendation thereof by <?php  echo $name;?> and do not constitute or imply endorsement, sponsorship or recommendation of <?php  echo $name;?> by the respective trademark owner.</p>
				</div>
			</div>
		</div>
	</footer>
	<style>
	h6 {
		color: #fff;
		font-size: 20px;
		font-weight: 600;
		padding-bottom: 5px;
	}
	
	.copyBox {
		text-align: center;
		background: #053da7;
		/*float: left;*/
		width: 100%;
		margin-top: 15px;
		margin-bottom: 19px;
		padding: 20px 0px;
	}
	
	.disclaimer_txt p {
		font-size: 12px;
		color: #fff;
		margin-bottom: 30px;
	}
	
	.press_logos {
		float: left;
		width: 100%;
		padding: 20px 0;
		background: #053da7;
		text-align: center;
	}
	
	footer {
		margin: 0;
		float: left;
		width: 100%;
		padding-top: 50px;
	}
	.modal.in .modal-dialog {
        display: flex;
        justify-content: center;
        align-items: center;
    }
	</style>
	<div class="main-ordernow-list">
		<div id="myModal" class="modal fade" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>
					<div class="modal-body">
						<!--<div class="row" style="text-align:center;">-->
						<!--	<div class="col-md-12"> <img style="height: 75px;padding: 0px;" src="assets/images/logo.png"> </div>-->
						<!--</div>-->
						<div class="row" style="padding: 10px;">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="info-list">
									<h3>Get 70% Discount</h3>
									<p>fill hout this brief form to get your discount reserved.</p>
									<form action="javascript:;" method="POST" class="form-get-quote-package form-get-quote">
										<div class="row">
											<div class="col-md-12 col-sm-12 col-xs-12">
												<div class="info-list">
													<input type="text" name="quote[name]" placeholder="Full Name" required>
													<i class="fa fa-user"></i>
													<p class="name-status" style="color:red"></p>
												</div>
											</div>
											<div class="col-md-12 col-sm-12 col-xs-12">
												<div class="info-list">
													<input type="email" name="quote[email]" placeholder="Email" required>
													<i class="fa fa-envelope"></i>
													<p class="email-status" style="color:red"></p>
												</div>
											</div>
											<div class="col-md-12 col-sm-12 col-xs-12">
												<div class="info-list">
													<input type="text" class="phoneNum" name="quote[phone]" placeholder="Contact Number"   required>
													<i class="fa fa-phone" aria-hidden="true"></i>
													<p class="phone-status" style="color:red"></p>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-12 col-sm-12 col-xs-12">
												<div class="info-list">
													<textarea placeholder="Message" name="quote[message]"></textarea>
													<i class="fa fa-paper-plane" aria-hidden="true"></i>
													<p class="about-status" style="color:red"></p>
													<!--<label>Please tell us briefly about your business or the services you provide</label>-->
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-12 col-sm-12 col-xs-12">
											<div class="info-list">
													<button style="display:none" class=" btn-fill btn-quote buttonload"><i class="fa fa-spinner fa-spin"></i>Loading</button>
													<button type="submit" name="submit">Submit Request</button>
												</div>
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="main-ordernow-list">
		<div id="myModal2" class="modal fade" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>
					<div class="modal-body">
						<div class="row" style="text-align:center;">
							<div class="col-md-12"> <img style="height: 75px;padding: 0px;" src="assets/images/logo.png"> </div>
						</div>
						<div class="row" style="padding: 10px;">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="info-list">
									<h3>Your <strong>Information</strong></h3>
									<p>If you are interested in speaking with <?php  echo $name;?> about an upcoming project, there are a number of ways we can make that happen. Filling out the form would help us get the right person in touch with you, or you could give us a call.</p>
									<form action="javascript:;" method="POST" class="form-get-quote-package form-get-quote">
										<div class="row">
											<div class="col-md-4 col-sm-4 col-xs-12">
												<div class="info-list">
													<input type="text" name="quote[name]" placeholder="Full Name" required>
													<p class="name-status" style="color:red"></p>
												</div>
											</div>
											<div class="col-md-4 col-sm-4 col-xs-12">
												<div class="info-list">
													<input type="email" name="quote[email]" placeholder="Email" required>
													<p class="email-status" style="color:red"></p>
												</div>
											</div>
											<div class="col-md-4 col-sm-4 col-xs-12">
												<div class="info-list">
													<input type="text" class="phoneNum" name="quote[phone]" placeholder="Contact Number" required>
													<p class="phone-status" style="color:red"></p>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6 col-sm-6 col-xs-12">
												<div class="info-list">
													<input type="text" name="quote[message]" placeholder="Title of your design">
													<p class="title-status" style="color:red"></p>
												</div>
											</div>
											<div class="col-md-6 col-sm-6 col-xs-12">
												<div class="info-list">
													<input type="text" name="quote[package]" class="PackageName" placeholder="Start Logo Package" readonly>
													<p class="package-status" style="color:red"></p>
												</div>
											</div>
										</div>
										<div class="row"> </div>
										<div class="row">
											<div class="col-md-4 col-sm-4 col-xs-12">
												<div class="info-list">
													<input type="text" name="price" class="PackagePrice" placeholder="$899" readonly>
													<p class="price-status" style="color:red"></p>
												</div>
											</div>
											<div class="col-md-4 col-sm-4 col-xs-12">
												<div class="info-list">
													<input type="text" name="design_features" placeholder="Add Unique Design Features">
													<p class="features-status" style="color:red"></p>
												</div>
											</div>
											<div class="col-md-4 col-sm-4 col-xs-12">
												<div class="info-list">
													<input type="text" name="design_caption" placeholder="Design Caption">
													<p class="caption-status" style="color:red"></p>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6 col-sm-12 col-xs-12">
												<div class="info-list">
													<textarea placeholder="Business Description" name="busi_descrip"></textarea>
													<p class="about-status" style="color:red"></p>
													<label>Please tell us briefly about your business or the services you provide</label>
												</div>
											</div>
											<div class="col-md-6 col-sm-12 col-xs-12">
												<div class="info-list">
													<textarea placeholder="Design Perception" name="design_perception"></textarea>
													<p class="perception-status" style="color:red"></p>
													<label>What kind of a design do you want to portray i.e. fun, corporate, funky etc.</label>
												</div>
											</div>
										</div>
										<input type="hidden" value="is_package" name="is_package">
										<div class="row">
											<div class="col-md-12 col-sm-12 col-xs-12">
											<div class="info-list">
													<button style="display:none" class=" btn-fill btn-quote buttonload"><i class="fa fa-spinner fa-spin"></i>Loading</button>
													<button type="submit" name="submit">Submit Request</button>
												</div>
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script src="assets/js/app.js"></script>
	<!--<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>-->
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/jquery.inputmask.bundle.js" type="text/javascript">
    </script>
	<script src="assets/js/selectFx.js"></script>
	<script src="assets/js/scripts.js"></script>
	<!--<script src="https://cdn.jsdelivr.net/npm/sweetalert2%4010/dist/sweetalert2.all.min.js"></script>-->
	<!-- Start of designflithelp Zendesk Widget script -->
    <script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=570ad7cb-9cae-4f57-a404-96abc1cd8b95"> </script>
    <!-- End of designflithelp Zendesk Widget script -->
	
	<script>
	zE(function() {
        $zopim(function() {
            $zopim.livechat.setOnUnreadMsgs(unread);

            function unread(number) {
                if (number >= 1) {
                    $zopim.livechat.window.show();
                }
            }
        });
    });
    window.setTimeout(function() {
        $zopim.livechat.button.show();
        $zopim.livechat.window.show();
        $zopim.livechat.bubble.show();
    }, 1000);
	$('.tabbing-links li').click(function() {
		$('.tabbing-links li').removeClass('current');
		$(this).addClass('current');
		var id = $(this).attr('data-targetit');
		$('.tab-custom .tabs').removeClass('current')
		$('.' + id).addClass('current');
	})
	$(document).ready(function() {
		// Add smooth scrolling to all links
		$("header a").on('click', function(event) {
			// Make sure this.hash has a value before overriding default behavior
			if(this.hash !== "") {
				// Prevent default anchor click behavior
				event.preventDefault();
				// Store hash
				var hash = this.hash;
				// Using jQuery's animate() method to add smooth page scroll
				// The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
				$('html, body').animate({
					scrollTop: $(hash).offset().top
				}, 800, function() {
					// Add hash (#) to URL when done scrolling (default click behavior)
					window.location.hash = hash;
				});
			} // End if
		});
	});
// 	$('.Btnallone').click(function() {
//       var vs = jQuery(this).attr('data-name');
//       var ss = vs.split('~');
       
//       var pTitle = ss[0]; 
//       console.log(pTitle);
//       var pkgTitle ="";
//       var pkgDesc ="";
//       var pkgDescli ="";
//       var pkgPrice = "";
//       if(pTitle == "COMBO PACKAGE "){
//             pkgTitle = pTitle;
//             pkgPrice = jQuery(this).parent().parent().parent().find(".price").text();
//             pkgDesc = 'Logo Design 5 Custom Logo Design Concepts By 2 Designers Icon Design File Formats (PSD, PDF, AI, JPEG, PNG) Stationary Business Card, Letterhead, Envelope, Fax Template MS Word Letterhead Social Media Facebook Page Design Twitter Page Design YouTube Page Design Google+ Page Design Instagram Page Design All Final File Formats Website 5 Pages Website CMS / Admin Panel Mobile Responsive Team of Expert Designers & Developers 8 Stock images 5 Banner Designs jQuery Sliders Free Google Friendly Sitemap Complete W3C Certified HTML Complete Deployment Value Added Services All Final File Formats Dedicated Account Manager 100% Ownership Rights 100% Satisfaction Guarantee 100% Unique Design Guarantee 100% Money Back Guarantee'; //jQuery(this).find(".doublewrap .row").text();
//             pkgDescli = '<li class="heading">Logo Design</li><li>5 Custom Logo Design Concepts</li><li>By 2 Designers</li><li>Icon Design</li><li>File Formats (PSD, PDF, AI, JPEG, PNG)</li><li class="heading">Stationary</li><li>Business Card, Letterhead, Envelope, Fax Template</li><li>MS Word Letterhead</li><li class="heading">Social Media</li><li>Facebook Page Design</li><li>Twitter Page Design</li><li>YouTube Page Design</li><li>Google+ Page Design</li><li>Instagram Page Design</li><li>All Final File Formats</li><li class="heading">Website</li><li>5 Pages Website</li><li>CMS / Admin Panel</li><li>Mobile Responsive</li><li>Team of Expert Designers &amp; Developers</li><li>8 Stock images</li><li>5 Banner Designs</li><li>jQuery Sliders</li><li>Free Google Friendly Sitemap</li><li>Complete W3C Certified HTML</li><li>Complete Deployment</li><li class="heading">Value Added Services</li><li>All Final File Formats</li><li>Dedicated Account Manager</li><li>100% Ownership Rights</li><li>100% Satisfaction Guarantee</li><li>100% Unique Design Guarantee</li><li>100% Money Back Guarantee</li>';
//       }else{
//             pkgTitle = pTitle;
// 		    pkgPrice = jQuery(this).parent().parent().parent().find(".price").text();
//     		pkgDesc = jQuery(this).parent().parent().parent().find(".wrap ul").text();
//     		pkgDescli = jQuery(this).parent().parent().parent().find(".wrap ul").html();
//       }
		 
        
//         jQuery("input.pack-tit").val(pkgTitle);
// 		jQuery("input.pack-pri").val(pkgPrice);
// 		jQuery("input.package_detail").val(pkgDesc);
// 		jQuery("input.package_detail_li").val(pkgDescli);

// 		var vs = jQuery(this).attr('data-name');
		
		
// 		//console.log(vs);
		
// 		jQuery('.PackagePrice').val(ss[0]);
// 		jQuery('.PackageName').val(pkgTitle);
// 	});
	</script>
	<script>
	$('.rotatekaro').click(function() {
		console.log('ths');
		$('.floating_form').toggleClass('active');
	})
	</script>

</body>

<script>
    $(".phoneNum").inputmask({
        "mask": "+9(999) 999-9999"
    }).on("input", function() {
        var minLength = 11; // minimum length of the formatted phone number, including the country code
        var phoneNumber = $(this).val().replace(/\D/g, ''); // remove non-digit characters from the input value
        if (phoneNumber.length < minLength) {
            this.setCustomValidity("Phone number must have a minimum length of " + minLength + " digits");
        } else {
            this.setCustomValidity("");
        }
    });
    $('.form-get-quote').on('submit', function(e) {
        //$('.btn-quote').on('click' , function(e){        
        var obj = $(this);
        e.preventDefault();
        var data = $(obj).serialize();
        // alert()
        jQuery.ajax({
            url: "sendmail.php",
            // For Demo
            //url: window.location.origin + '/lvm-track-html/v6/sendmail.php',
            // For Live
            // url: window.location.origin + '/sendmail.php',
            type: "POST",
            data: data,
            async: false, // Has to be false to be able to return response
            dataType: "json", // Has to be false to be able to return response
            success: function(response) {
                if (response.status == 1) {
                    //$('#myModal').modal('hide');
                    //$('#myModal').modal('show');
                    //   alert('Submit Successfully.');
                    window.location =
                        "/thankyou.php";
                    obj.trigger("reset");
                } else {
                    return false;
                }
    
            },
            beforeSend: function() {
                // Loader.show();
            }
        });
    
        return false;
    });
</script>

</html>
