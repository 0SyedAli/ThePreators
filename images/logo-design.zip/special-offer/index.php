<!DOCTYPE html>
<html lang="en">

<head>
    <title> Affordable Professional Custom Logo Design Company</title>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php include '../includes/style.php';?>
    <meta name="description"
        content="<?php  echo $name;?> is the Top Logo Design Company based in USA. We Offer High-Quality Logo Design Services for Brands, Companies &amp; Startups of all Sizes.">
    <meta name="keywords"
        content="logo maker, logo design, brand logo, restaurant logo, creating a logo, business logos, construction logos, trucking logo, logo generators, logo design online, mascot logo, 3d logo, design logo, company logo design, custom logo design, business logo design, fitness logo, cafe logo, business logo maker, creative logo, boutique logo, logo builder, brand logo design, animated logo maker, company logo maker, logo design maker, adobe logo maker, custom logo maker, logo creator, business logo design, creative logo design, construction logo design, logo design company.">
    <link rel="icon" href="images/favicon.png" sizes="192x192">
    <link rel="apple-touch-icon" href="images/favicon.png">
    <link href="https://fonts.googleapis.com/css?family=Pathway+Gothic+One" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700,900" rel="stylesheet">
    <link rel="stylesheet" href="css/css-bootstrap.min.css">
    <link rel="stylesheet" href="css/css-animate.css">
    <link rel="stylesheet" href="css/css-font-awesome.css">
    <link rel="stylesheet" href="css/css-owl.carousel.min.css">
    <link rel="stylesheet" href="css/css-owl.theme.min.css">
    <link rel="stylesheet" href="css/css-owl.transitions.css">
    <link rel="stylesheet" href="css/css-style.css">
    <link rel="stylesheet" href="css/css-responsive.css">
    <link rel="stylesheet" href="css/css-jquery.mCustomScrollbar.min.css">
    <link rel="stylesheet" href="css/css-ionicons.css">
    <link rel="stylesheet" href="css/css-jquery.fancybox.css">

</head>

<body id="page-top">

    <section class="banner">
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-md-5 logoimg"> <a href="#"><img src="images/logo-white.png"
                                style="margin-top: 20px; width:50%" alt class="img-responsive"></a> </div>
                    <div class="col-md-7">
                        <ul class="head-cta">
                            <li> <a href="javascript:;.html" onclick="setButtonURL();" class="chat"><i
                                        class="fa fa-comments"></i> LIVE CHAT</a> </li>
                            <li><a href="tel:<?php  echo $phone;?>"><i class="fa fa-phone" aria-hidden="true"></i>
                                    <?php  echo $phone;?>
                                </a></li>
                            <li class="cta-order-btn"><a class="order_button open_modal_zee" href="javascript:void(0)"
                                    data-type="movetothankyou" name="for%20%2499">Order Now</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="logo-cards clearfix">
                        <div>
                            <div class="logo-card">
                                <div class="front"><img src="images/images-bn-flip-logo-1.jpg" alt></div>
                                <div class="back"><img src="images/resize-1.png" alt></div>
                            </div>
                        </div>
                        <div>
                            <div class="logo-card">
                                <div class="front"><img src="images/images-bn-flip-logo-2.jpg" alt></div>
                                <div class="back"><img src="images/images-bn-flip-logo-2-2.jpg" alt></div>
                            </div>
                        </div>
                        <div>
                            <div class="logo-card">
                                <div class="front"><img src="images/images-bn-flip-logo-3.jpg" alt></div>
                                <div class="back"><img src="images/resize-2.png" alt></div>
                            </div>
                        </div>
                        <div>
                            <div class="logo-card">
                                <div class="front"><img src="images/images-bn-flip-logo-4.jpg" alt></div>
                                <div class="back"><img src="images/images-bn-flip-logo-4-4.jpg" alt></div>
                            </div>
                        </div>
                        <div>
                            <div class="logo-card">
                                <div class="front"><img src="images/images-bn-flip-logo-5.jpg" alt></div>
                                <div class="back"><img src="images/resize-3.png" alt></div>
                            </div>
                        </div>
                        <div>
                            <div class="logo-card">
                                <div class="front"><img src="images/images-bn-flip-logo-6.jpg" alt></div>
                                <div class="back"><img src="images/images-bn-flip-logo-6-6.jpg" alt></div>
                            </div>
                        </div>
                        <div>
                            <div class="logo-card">
                                <div class="front"><img src="images/images-bn-flip-logo-7.jpg" alt></div>
                                <div class="back"><img src="images/resize-4.png" alt></div>
                            </div>
                        </div>
                        <div>
                            <div class="logo-card">
                                <div class="front"><img src="images/images-bn-flip-logo-8.jpg" alt></div>
                                <div class="back"><img src="images/images-bn-flip-logo-8-8.jpg" alt></div>
                            </div>
                        </div>
                        <div>
                            <div class="logo-card">
                                <div class="front"><img src="images/images-bn-flip-logo-9.jpg" alt></div>
                                <div class="back"><img src="images/resize-5.png" alt></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-md-offset-1 header-content">
                    <h2><span>AWARD WINNING LOGO SERVICES</span> BY WORLD'S # 1 DESIGN AGENCY</h2>
                    <p class="header-content">Your identity is just one step ahead with your BRAND recognition.</p>
                    <div class="slideform" id="slideforma">
                        <h2 class="h-title">PRICE STARTING FROM <span>$25</span></h2>
                        <h3><span><span style="color:#43b2c3">70% OFF </span>– LIMITED TIME OFFER</span> </h3>
                        <div class="form-box">
                            <form class="jform form-get-quote" action="javascript:;" method="POST">
                                <input type="text" name="quote[name]" placeholder="Name" class="iecn alphanumeric"
                                    required>
                                <input type="email" name="quote[email]" placeholder="Email"
                                    class="email email_slider_form" required>
                                <input type="text" name="quote[phone]"
                                    placeholder="Phone Number" class="number phoneNum" required>
                                <input type="submit" name="submit" class="btn-validate btn-orangedark"
                                    value="Get Started Now">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="who-we-are">
        <div class="container">
            <div class="row top-heading_row">
                <div class="col-md-2"></div>
                <div class="col-md-8">
                    <div class="section_title">
                        <h2> LOGO TYPES </h2>
                    </div>
                </div>
                <div class="col-md-2"></div>
            </div>
            <div class="row tabs_row">
                <div class="col-md-12">
                    <ul class="nav nav-tabs nav-justified">
                        <li class="active"><a data-toggle="tab" href="#tab1">Abstract <span>Design</span></a></li>
                        <li><a data-toggle="tab" href="#tab2">3D <span>Design</span></a></li>
                        <li><a data-toggle="tab" href="#tab3">Flat <span>Design</span></a></li>
                        <li><a data-toggle="tab" href="#tab4">Illustrative <span>Design</span></a></li>
                        <li><a data-toggle="tab" href="#tab5">Iconic <span>Design</span></a></li>
                        <li><a data-toggle="tab" href="#tab6">Realistic <span>Design</span></a></li>
                        <li><a data-toggle="tab" href="#tab7">Wordmark <span>Design</span></a></li>
                    </ul>
                    <div class="tab-content">
                        <div id="tab1" class="tab-pane fade in active">
                            <div class="row">
                                <div class="col-md-6"> <img src="images/images-site-img17.png" alt="image"
                                        class="img-responsive center-block lazy"> </div>
                                <div class="col-md-6">
                                    <div class="tab-contents">
                                        <h3> Abstract Design </h3>
                                        <p> Abstract logo designs also known as smart logos is a mix of pictures,
                                            typography and shapes. A lot of organizations today use abstract logos for
                                            their businesses. They are usually used as a conceptual strategy to
                                            represent your business idea. It also allows you to exhibit different
                                            functions of your company. Join hands with <span class="text-grad">tel:(123)
                                                456-7890</span> to create your abstract logo that reflects an unclear
                                            vision of your business – so that you can play safe in your business
                                            operations. </p>
                                        <a href="javascript:void(0)" data-type="movetothankyou"
                                            class="btn grad-color read-more-info open_modal_zee">Let's Get Started</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="tab2" class="tab-pane fade">
                            <div class="row">
                                <div class="col-md-6"> <img src="images/images-site-img10.png" alt="image"
                                        class="img-responsive center-block lazy"> </div>
                                <div class="col-md-6">
                                    <div class="tab-contents">
                                        <h3> 3D Design </h3>
                                        <p> If you’re looking for a modern style logo – our 3-Dimensional logo designs
                                            will serve you best. We specialize in making 3D logos which reflects your
                                            brand in an attractive way. With our abundant 3D logo designs – enjoy the
                                            rewards of attracting a large number of clients as your audience will be
                                            able to experience look and feel of your business. Ping us now and let’s add
                                            some dimensions to your boring logo designs. </p>
                                        <a href="javascript:void(0)" data-type="movetothankyou"
                                            class="btn grad-color read-more-info open_modal_zee">Let's Get Started</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="tab3" class="tab-pane fade">
                            <div class="row">
                                <div class="col-md-6"> <img src="images/images-site-img11.png" alt="image"
                                        class="img-responsive center-block lazy"> </div>
                                <div class="col-md-6">
                                    <div class="tab-contents">
                                        <h3> Flat Design </h3>
                                        <p> Flat design or a minimalistic logo design is a clean and crisp image bearing
                                            bright colors and two-dimensional illustrations. <span
                                                class="text-grad"><?php  echo $name;?></span> helps you create a simple,
                                            yet
                                            innovative flat logo deigns that are classic and cluster free. We make sure
                                            that your flat designs are a combination of solid, vivid colors, concise
                                            text and to-the-point. </p>
                                        <a href="javascript:void(0)" data-type="movetothankyou"
                                            class="btn grad-color read-more-info open_modal_zee">Let's Get Started</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="tab4" class="tab-pane fade">
                            <div class="row">
                                <div class="col-md-6"> <img src="images/images-computer.png" alt="image"
                                        class="img-responsive center-block lazy"> </div>
                                <div class="col-md-6">
                                    <div class="tab-contents">
                                        <h3> Illustrative Design </h3>
                                        <p> If you want to create a work of art – illustrative logos are the best fit as
                                            it contains intricate artwork. It will act as a trendy as well as
                                            contemporary image of your brand and keep the viewers attention longer than
                                            the traditional logo design. We at <span
                                                class="text-grad"><?php  echo $name;?>
                                                Design Agency</span> use latest tools and technology to create a
                                            remarkable illustrative logo for your brand. </p>
                                        <a href="javascript:void(0)" data-type="movetothankyou"
                                            class="btn grad-color read-more-info open_modal_zee">Let's Get Started</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="tab5" class="tab-pane fade">
                            <div class="row">
                                <div class="col-md-6"> <img src="images/images-site-img8.png"
                                        class="img-responsive center-block lazy" alt="image" style="margin-top:10px;">
                                </div>
                                <div class="col-md-6">
                                    <div class="tab-contents">
                                        <h3> Iconic Design </h3>
                                        <p> Our experts create iconic logo designs that are versatile and memorable. Our
                                            iconic logos will help you boost your brand affinity. It will reflect your
                                            brand culture and goals. Iconic logos are self-explanatory and team <span
                                                class="text-grad"><?php  echo $name;?></span> love to experiment with
                                            new
                                            techniques and color coding so that your logo becomes a talking symbol of
                                            your brand. </p>
                                        <a href="javascript:void(0)" data-type="movetothankyou"
                                            class="btn grad-color read-more-info open_modal_zee">Let's Get Started</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="tab6" class="tab-pane fade">
                            <div class="row">
                                <div class="col-md-6"> <img src="images/images-site-img12.png" alt="image"
                                        class="img-responsive center-block lazy"> </div>
                                <div class="col-md-6">
                                    <div class="tab-contents">
                                        <h3> Realistic Design </h3>
                                        <p> Realistic designs are the enchanted graphical representations of your
                                            business. We help you create a logo design that incorporates your brand
                                            roots. Whether you are a start up, medium enterprise or a large-scale
                                            business - Realistic logos are for everyone who wishes to build a strong
                                            brand image. </p>
                                        <a href="javascript:void(0)" data-type="movetothankyou"
                                            class="btn grad-color read-more-info open_modal_zee">Let's Get Started</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="tab7" class="tab-pane fade">
                            <div class="row">
                                <div class="col-md-6"> <img src="images/images-site-img9.png" alt="image"
                                        class="img-responsive center-block lazy"> </div>
                                <div class="col-md-6">
                                    <div class="tab-contents">
                                        <h3> Wordmark Design </h3>
                                        <p> Create your professional wordmark logo with <span
                                                class="text-grad"><?php  echo $name;?></span>. It is a pure form of logo
                                            and a text-only
                                            representation of your brand – which makes it a good choice for start-ups
                                            and accelerating businesses that are seeking a static and no-hassle
                                            solution. We allow full customization to create your own wordmark logo
                                            design to enhance your brand visibility. </p>
                                        <a href="javascript:void(0)" data-type="movetothankyou"
                                            class="btn grad-color read-more-info open_modal_zee">Let's Get Started</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="packages portfolio-sec">
        <img src="images/images-packages-offer.png" class="shape">
        <div class="container">
            <div class="row text-center">
                <div class="col-m-12">
                    <h1 class="wow fadeInUp">Logo Packages We Offer</h1>
                    <p class="wow fadeInUp">tel:<?php  echo $phone;?> believes in delivering distinctive services in
                        competitive price models. We have some attractive packages especially crafted for every service
                        offered to offer the finest quality within the budget. </p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="mission-tab ">
                        <div class="tabs logo-pricing">
                            <ul class="nav nav-tabs top-tabs web-tabs" id="interest_tabs">
                            </ul>
                            <div class="tab-content">
                                <div id="illus-pkg" class="tab-pane active">
                                    <div class="row mr">
                                        <div class="col-md-4">
                                            <div class="pricing-box one">
                                                <div class="collapse-top collapsed" data-target="#one"
                                                    aria-expanded="true">
                                                    <div class="price-box">
                                                        <h6><strike>$99</strike> $30 </h6>
                                                        <p><strong class="text-uppercase">BEGINNERS LOGO
                                                                Package</strong><br>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="collapse-div" id="one">
                                                    <div class="package-list">
                                                        <ul class="getul ulzee">
                                                            <li>2 Logo Design Concepts</li>
                                                            <li>2 Revision</li>
                                                            <li>By 1 Logo Designer</li>
                                                            <li>JPEG Formats</li>
                                                            <li>48 to 72 hours TAT</li>
                                                            <li><b>MORE FEATURES</b></li>
                                                            <li>100% Money Back Guarantee*</li>
                                                            <li>100% Satisfaction Guarantee</li>
                                                            <li>100% Unique Design Guarantee</li>
                                                            <li>Dedicated Account Executive</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="call-to">
                                                    <div>
                                                        <p>Start Your Work</p>
                                                        <p><a href="tel:<?php  echo $phone;?>"><?php  echo $phone;?></a>
                                                        </p>
                                                    </div>
                                                    <div>
                                                        <p>For More Detail</p>
                                                        <p><a href="javascript:void(0)" onclick="setButtonURL();">Chat
                                                                With us</a></p>
                                                    </div>
                                                </div>
                                                <script>
                                                var desc =
                                                    "<li>2 Logo Design Concepts<li>By 1 Logo Designer<li>2 Revisions<li>JPEG Formats<li>48 to 72 hours TAT";
                                                </script>
                                                <a class="order_now open_modal_zee"
                                                    onclick="order_now_value('25', 'BEGINNERS LOGO Package', desc)"
                                                    href="javascript:void(0)" name="for%20%2419">Order Now</a>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="pricing-box two">
                                                <div class="collapse-top collapsed" data-target="#two"
                                                    aria-expanded="true">
                                                    <div class="price-box">
                                                        <h6><strike>$149</strike> $69</h6>
                                                        <p><strong class="text-uppercase"> Advance Logo Package</strong>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="collapse-div" id="two">
                                                    <div class="package-list">
                                                        <ul class="getul">
                                                            <li>5 Logo Design Concepts</li>
                                                            <li>3 Revisions</li>
                                                            <li>By 2 Logo Designers</li>
                                                            <li>Free Color Options</li>
                                                            <li>All File Formats:</li>
                                                            <li>PNG, JPG, PDF</li>
                                                            <li>48 to 72 hours TAT</li>
                                                            <li><b>MORE FEATURES</b></li>
                                                            <li>100% Money Back Guarantee*</li>
                                                            <li>100% Satisfaction Guarantee</li>
                                                            <li>100% Unique Design Guarantee</li>
                                                            <li>Dedicated Account Executive</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="call-to">
                                                    <div>
                                                        <p>Start Your Work</p>
                                                        <p><a href="tel:<?php  echo $phone;?>"><?php  echo $phone;?></a>
                                                        </p>
                                                    </div>
                                                    <div>
                                                        <p>For More Detail</p>
                                                        <p><a href="javascript:void(0)" onclick="setButtonURL();">Chat
                                                                With us</a></p>
                                                    </div>
                                                </div>
                                                <script>
                                                var desc =
                                                    "<li>5 Logo Design Concepts<li>3 Revisions<li>By 2 Logo Designers<li>Free Color Options<li>All File Formats:<li>PNG, JPG, PDF<li>48 to 72 hours TAT<li><b>MORE FEATURES<li>100% Money Back Guarantee*<li>100% Satisfaction Guarantee<li>100% Unique Design Guarantee<li>Dedicated Account Executive";
                                                </script>
                                                <a class="order_now open_modal_zee"
                                                    onclick="order_now_value('70', 'ADVANCE LOGO Package', desc)"
                                                    href="javascript:void(0)" name="for%20%2459">Order Now</a>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="pricing-box three">
                                                <div class="collapse-top collapsed" data-target="#three"
                                                    aria-expanded="true">
                                                    <div class="price-box">
                                                        <h6><strike>$299</strike> $125</h6>
                                                        <p><strong class="text-uppercase">Corporate Logo
                                                                Package</strong></p>
                                                    </div>
                                                </div>
                                                <div class="collapse-div" id="three">
                                                    <div class="package-list">
                                                        <ul class="getul">
                                                            <li>7 Logo Design Concepts</li>
                                                            <li>7 Revisions</li>
                                                            <li>By 3 Logo Designers</li>
                                                            <li>Stationery Design (Print ready files)</li>
                                                            <li>Icon Design</li>
                                                            <li>Free Color Options</li>
                                                            <li>FREE File Formats:</li>
                                                            <li>AI, PSD, EPS, PNG, GIF, JPG, PDF</li>
                                                            <li><b>MORE FEATURES</b></li>
                                                            <li>100% Money Back Guarantee*</li>
                                                            <li>100% Satisfaction Guarantee</li>
                                                            <li>100% Unique Design Guarantee</li>
                                                            <li>Dedicated Account Executive</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="call-to">
                                                    <div>
                                                        <p>Start Your Work</p>
                                                        <p><a href="tel:<?php  echo $phone;?>"><?php  echo $phone;?></a>
                                                        </p>
                                                    </div>
                                                    <div>
                                                        <p>For More Detail</p>
                                                        <p><a href="javascript:void(0)" onclick="setButtonURL();">Chat
                                                                With us</a></p>
                                                    </div>
                                                </div>
                                                <script>
                                                var desc =
                                                    "<li>7 Logo Design Concepts<li>7 Revisions <li>By 3 Logo Designers<li>Stationery Design (Print ready files)<li>Icon Design<li>Free Color Options<li>FREE File Formats:<li>AI, PSD, EPS, PNG, GIF, JPG, PDF<li><b>MORE FEATURES<li>100% Money Back Guarantee*<li>100% Satisfaction Guarantee<li>100% Unique Design Guarantee<li>Dedicated Account Executive";
                                                </script>
                                                <a class="order_now open_modal_zee"
                                                    onclick="order_now_value('130', 'CORPORATE LOGO Package', desc)"
                                                    href="javascript:void(0)" name="for%20%2499">Order Now</a>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="row mr" style="margin-top: 50px">
                                        <div class="col-md-4">
                                            <div class="pricing-box one">
                                                <div class="collapse-top collapsed" data-target="#one"
                                                    aria-expanded="true">
                                                    <div class="price-box">
                                                        <h6><strike>$419</strike> $180</h6>
                                                        <p><strong class="text-uppercase">Silver Logo
                                                                Package</strong><br>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="collapse-div" id="one">
                                                    <div class="package-list">
                                                        <ul class="getul">
                                                            <li>10 Logo Design Concepts</li>
                                                            <li>10 Revisions</li>
                                                            <li>By 5 Logo Designers</li>
                                                            <li>Icon Design</li>
                                                            <li>Email Signature Design</li>
                                                            <li>Stationery Design (Business Card)</li>
                                                            <li>Free Color Options</li>
                                                            <li>FREE File Formats:</li>
                                                            <li>AI, PSD, EPS, PNG, GIF, JPG, PDF</li>
                                                            <li>48 to 72 hours TAT</li>
                                                            <li><b>MORE FEATURES </b></li>
                                                            <li>100% Money Back Guarantee*</li>
                                                            <li>100% Satisfaction Guarantee</li>
                                                            <li>100% Unique Design Guarantee</li>
                                                            <li>Dedicated Account Executive</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="call-to">
                                                    <div>
                                                        <p>Start Your Work</p>
                                                        <p><a href="tel:<?php  echo $phone;?>"><?php  echo $phone;?></a>
                                                        </p>
                                                    </div>
                                                    <div>
                                                        <p>For More Detail</p>
                                                        <p><a href="javascript:void(0)" onclick="setButtonURL();">Chat
                                                                With us</a></p>
                                                    </div>
                                                </div>
                                                <script>
                                                var desc =
                                                    "<li>10 Logo Design Concepts<li>10 Revisions<li>By 5 Logo Designers<li>Icon Design<li>Email Signature Design<li>Stationery Design (Business Card) <li>Free Color Options<li>FREE File Formats: <li>AI, PSD, EPS, PNG, GIF, JPG, PDF<li>48 to 72 hours TAT<li><b>MORE FEATURES <li>100% Money Back Guarantee*<li>100% Satisfaction Guarantee<li>100% Unique Design Guarantee<li>Dedicated Account Executive";
                                                </script>
                                                <a class="order_now open_modal_zee"
                                                    onclick="order_now_value('180', 'SILVER LOGO Package', desc)"
                                                    href="javascript:void(0)" name="for%20%24149">Order Now</a>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="pricing-box two">
                                                <div class="collapse-top collapsed" data-target="#two"
                                                    aria-expanded="true">
                                                    <div class="price-box">
                                                        <h6><strike>$619</strike> $250</h6>
                                                        <p><strong class="text-uppercase">Platinum Logo Package</strong>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="collapse-div" id="two">
                                                    <div class="package-list">
                                                        <ul class="getul">
                                                            <li>Unlimited Concepts</li>
                                                            <li>Unlimited Revisions</li>
                                                            <li>By 5 Logo Designers</li>
                                                            <li>Flyer Design</li>
                                                            <li>Icon Design</li>
                                                            <li>MS Word Letter Design</li>
                                                            <li>Email Signature Design</li>
                                                            <li>Stationery Design (Business Card, Letterhead, Envelope)
                                                            </li>
                                                            <li>Free Color Options</li>
                                                            <li>FREE File Formats:</li>
                                                            <li>AI, PSD, EPS, PNG, GIF, JPG, PDF</li>
                                                            <li>48 to 72 hours TAT</li>
                                                            <li><b>MORE FEATURES </b></li>
                                                            <li>100% Money Back Guarantee*</li>
                                                            <li>100% Satisfaction Guarantee</li>
                                                            <li>100% Unique Design Guarantee</li>
                                                            <li>Dedicated Account Executive</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="call-to">
                                                    <div>
                                                        <p>Start Your Work</p>
                                                        <p><a href="tel:<?php  echo $phone;?>"><?php  echo $phone;?></a>
                                                        </p>
                                                    </div>
                                                    <div>
                                                        <p>For More Detail</p>
                                                        <p><a href="javascript:void(0)" onclick="setButtonURL();">Chat
                                                                With us</a></p>
                                                    </div>
                                                </div>
                                                <script>
                                                var desc =
                                                    "<li>Unlimited Concepts<li>Unlimited Revisions<li>By 5 Logo Designers<li>Flyer Design<li>Icon Design<li>MS Word Letter Design<li>Email Signature Design<li>Stationery Design (Business Card, Letterhead, Envelope) <li>Free Color Options<li>FREE File Formats:<li>AI, PSD, EPS, PNG, GIF, JPG, PDF<li>48 to 72 hours TAT<li><b>MORE FEATURES <li>100% Money Back Guarantee*<li>100% Satisfaction Guarantee<li>100% Unique Design Guarantee<li>Dedicated Account Executive";
                                                </script>
                                                <a class="order_now open_modal_zee"
                                                    onclick="order_now_value('250', 'PLATINUM LOGO Package', desc)"
                                                    href="javascript:void(0)" name="for%20%24199">Order Now</a>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="pricing-box three">
                                                <div class="collapse-top collapsed" data-target="#three"
                                                    aria-expanded="true">
                                                    <div class="price-box">
                                                        <h6><strike>$1499</strike> $999</h6>
                                                        <p><strong class="text-uppercase">SPECIAL Combo Package</strong>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="collapse-div" id="three">
                                                    <div class="package-list">
                                                        <ul class="getul">
                                                            <li>– Logo Design</li>
                                                            <li>5 Logo Design Concepts</li>
                                                            <li>Unlimited Revisions</li>
                                                            <li>Icon Design</li>
                                                            <li>All Final File Formats</li>
                                                            <li>– Business Stationary</li>
                                                            <li>Business Card, Letterhead, Envelope, MS Word Letterhead
                                                            </li>
                                                            <li>– Website Design</li>
                                                            <li>5 Page Website</li>
                                                            <li>Unlimited Revisions</li>
                                                            <li>Content Management System</li>
                                                            <li>2 Stock images</li>
                                                            <li>2 Banner Designs</li>
                                                            <li>jQuery Sliders</li>
                                                            <li>2 Social Media Platforms Setup</li>
                                                            <li><b>MORE FEATURES</b></li>
                                                            <li>Logo Design Final Files (.PNG, .JPG, .PDF)</li>
                                                            <li>Website Design Complete Source Files</li>
                                                            <li>100% Money Back Guarantee*</li>
                                                            <li>100% Satisfaction Guarantee</li>
                                                            <li>100% Unique Design Guarantee</li>
                                                            <li>Dedicated Account Executive</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="call-to">
                                                    <div>
                                                        <p>Start Your Work</p>
                                                        <p><a href="tel:<?php  echo $phone;?>"><?php  echo $phone;?></a>
                                                        </p>
                                                    </div>
                                                    <div>
                                                        <p>For More Detail</p>
                                                        <p><a href="javascript:void(0)" onclick="setButtonURL();">Chat
                                                                With us</a></p>
                                                    </div>
                                                </div>
                                                <script>
                                                var desc =
                                                    "<li>&ndash; Logo Design<li>5 Logo Design Concepts<li>Unlimited Revisions<li>Icon Design<li>All Final File Formats<li>&ndash; Business Stationary<li>Business Card, Letterhead, Envelope, MS Word Letterhead	<li>&ndash; Website Design<li>5 Page Website<li>Unlimited Revisions<li>Content Management System<li>2 Stock images<li>2 Banner Designs <li>jQuery Sliders<li>2 Social Media Platforms Setup<li><b>MORE FEATURES<li>Logo Design Final Files (.PNG, .JPG, .PDF) <li>Website Design Complete Source Files<li>100% Money Back Guarantee*<li>100% Satisfaction Guarantee <li>100% Unique Design Guarantee<li>Dedicated Account Executive";
                                                </script>
                                                <a class="order_now open_modal_zee"
                                                    onclick="order_now_value('999', 'SPECIAL COMBO Package', desc)"
                                                    href="javascript:void(0)" name="for%20%24499">Order Now</a>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="clearfix"></div>
    <div class="clearfix"></div>
    <section class="portfolio-sec">
        <img src="images/images-client-bg.png" class="shape">
        <div class="container">
            <h1 class="wow fadeInUp"><span>Our Work</span> <br><br> Logo Portfolio</h1>
            <div class="row">
                <div class="col-md-12">
                    <div class="mission-tab">
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane fade in active" id="logo">
                                <div class="tabs logo logo-portfolio">
                                    <ul class="nav nav-tabs top-tabs web-tabs" id="interest_tabs">
                                        <li class="active"><a href="#abs-logo" data-toggle="tab"
                                                aria-expanded="false">Abstract <span>Design</span></a></li>
                                        <li class><a href="#flat-logo" data-toggle="tab" aria-expanded="false">Flat
                                                <span>Design</span></a></li>
                                        <li class><a href="#mascot-logo" data-toggle="tab" aria-expanded="false">Mascot
                                                <span>Design</span></a></li>
                                        <li class><a href="#icon-logo" data-toggle="tab" aria-expanded="true">Iconic
                                                <span>Design</span></a></li>
                                        <li class><a href="#illus-logo" data-toggle="tab"
                                                aria-expanded="false">Illustrative <span>Design</span> </a></li>
                                    </ul>

                                    <div class="tab-content">

                                        <div id="abs-logo" class="tab-pane active">
                                            <div class="row mr">
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-1.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a href="images/images-1.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-2.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a href="images/images-2.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-3.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a href="images/images-3.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-4.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a href="images/images-4.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-5.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a href="images/images-5.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-6.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a href="images/images-6.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-7.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a href="images/images-7.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-8.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a href="images/images-8.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-9.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a href="images/images-9.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div id="flat-logo" class="tab-pane">
                                            <div class="row mr">
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-1%20(1).jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-1%20(1).jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-2%20(1).jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-2%20(1).jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-3%20(1).jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-3%20(1).jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-4%20(1).jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-4%20(1).jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-5.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-5%20(1).jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-6%20(2).jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-6%20(2).jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-7%20(1).jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-7%20(1).jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-8%20(1).jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-8%20(1).jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-9%20(1).jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-9%20(1).jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div id="mascot-logo" class="tab-pane">
                                            <div class="row mr">
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-mascots_1.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-mascots_1.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-mascots_2.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-mascots_2.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-mascots_3.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-mascots_3.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-mascots_4.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-mascots_4.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-mascots_5.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-mascots_5.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-mascots_6.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-mascots_6.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-mascots_7.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-mascots_7.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-mascots_8.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-mascots_8.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-mascots_9.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-mascots_9.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-mascots_10.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-mascots_10.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-mascots_11.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-mascots_11.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-mascots_12.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-mascots_12.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div id="icon-logo" class="tab-pane">
                                            <div class="row mr">
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-iconic_1.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-iconic_1.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-iconic_2.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-iconic_2.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-iconic_3.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-iconic_3.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-iconic_4.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-iconic_4.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-iconic_5.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-iconic_5.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-iconic_6.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-iconic_6.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-iconic_7.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-iconic_7.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-iconic_8.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-iconic_8.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-iconic_9.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-iconic_9.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div id="illus-logo" class="tab-pane">
                                            <div class="row mr">
                                                <div class="col-md-4 col-sm-6 col-xs-12 ">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative1.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-illustrative1.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-12">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative2.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a href="images/images-2.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-12">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative3.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-illustrative3.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-12">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative4.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-illustrative4.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-12">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative5.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-illustrative5.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-12">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative6.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-illustrative6.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-12">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative7.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-illustrative7.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-12">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative8.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-illustrative8.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-12">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative9.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-illustrative9.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-12">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative10.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-illustrative10.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-12">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative11.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-illustrative11.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-12">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative12.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-illustrative12.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-12">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative13.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-illustrative13.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-12">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative14.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-illustrative/14.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-12">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative15.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-illustrative15.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-12">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative16.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-illustrative16.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-12">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative17.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-illustrative17.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-12">
                                                    <div class="wow fadeInLeft ">
                                                        <div class="hovereffect-portfolio">
                                                            <img src="images/images-illustrative18.jpg" alt="image"
                                                                class="img-responsive center-block">
                                                            <div class="overlayPort">
                                                                <ul class="info text-center list-inline">
                                                                    <li class="last"> <a
                                                                            href="images/images-illustrative18.jpg"
                                                                            class="fancybox-pop"> <i
                                                                                class="fa fa-search"></i> </a> </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="clearfix"></div>

    <section class="awards_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-12">
                    <div class="sec_headings">
                        <h2 class="set_head wow fadeInUp"><span>Awards</span></h2>
                    </div>
                </div>
                <div class="col-xl-10">
                    <div class="row logo-responsive-slider">
                        <div class="col-xl-2 col-lg-2 wow fadeInLeft animated">
                            <div class="award_box">
                                <img class="img-fluid" src="images/images-award1.png" alt>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 wow fadeInLeft animated">
                            <div class="award_box">
                                <img class="img-fluid" src="images/images-award2.png" alt>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 wow fadeInLeft animated">
                            <div class="award_box">
                                <img class="img-fluid" src="images/images-award3.png" alt>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 wow fadeInLeft animated">
                            <div class="award_box">
                                <img class="img-fluid" src="images/images-award4.png" alt>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 wow fadeInLeft animated">
                            <div class="award_box">
                                <img class="img-fluid" src="images/images-award5.png" alt>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 wow fadeInLeft animated">
                            <div class="award_box">
                                <img class="img-fluid" src="images/images-award6.png" alt>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="work_process">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="sec_headings">
                        <h2 class="set_head wow fadeInUp">Our Work Process</h2>
                        <p class="set_paras wow fadeInUp"><?php  echo $name;?> is loved and chosen by its clients
                            because of the
                            creative, aesthetically-pleasing and crisp design. All the design ninjas at our company are
                            industry-experienced and out of the box thinkers.</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="row justify-content-center work-responsive-slider">
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12p-0 wow zoomIn">
                            <div class="prcess_box">
                                <h2>Design Brief</h2>
                                <p>After getting the draft done, we review the design after getting your feedback from
                                    our QA department.</p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 p-0 wow zoomIn">
                            <div class="prcess_box">
                                <h2>Custom Designs</h2>
                                <p>We have expertise in designing custom logos for our clients. After analysing the
                                    needs of our clients, Our designers design custom logos as per your requirements.
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 p-0 wow zoomIn">
                            <div class="prcess_box">
                                <h2>Unlimited Revision</h2>
                                <p>Working with us give you unlimited benefits. You get unlimited revisions for your
                                    design.</p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 p-0 wow zoomIn">
                            <div class="prcess_box">
                                <h2>Delivery</h2>
                                <p>Our TAT is 24 hours, but if it is urgent then we can design your logo in just 1 hour.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 wow zoomIn">
                    <div class="work_right">
                        <img class="img-fluid" src="images/images-work_rights.png" alt>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="sec_headings wow fadeInUp testi-bg">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="sec_headings">
                        <h2 class="set_head testi-head wow fadeInUp">TESTIMONIAL</h2>
                    </div>
                </div>
                <div class="col-md-12">
                    <div id="testimonial-slider" class="owl-carousel">
                        <div class="testimonial">
                            <div class="pic">
                                <img src="images/images-img-1.jpg">
                            </div>
                            <h3 class="title">Evan Corondi</h3>
                            <p class="description">
                                Pleasantly surprised by the turnaround time and the quality in the choices I was
                                presented with which unfortunately made it hard to choose.
                            </p>
                        </div>
                        <div class="testimonial">
                            <div class="pic">
                                <img src="images/images-img-2.jpg">
                            </div>
                            <h3 class="title">Kristina</h3>
                            <p class="description">
                                Thanks for staying with the design and effort. I have an extremely complex schedule and
                                keeping this as the priority was difficult for me. Your persistence was greatly
                                appreciated.
                            </p>
                        </div>
                        <div class="testimonial">
                            <div class="pic">
                                <img src="images/images-img-3.jpg">
                            </div>
                            <h3 class="title">Chris Golden</h3>
                            <p class="description">
                                Service and turn-around time was top notch. They did everything I asked in an incredibly
                                fast time and the logo design turned out great!
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="contact-sec">
        <div class="container">
            <h2 class="text-center wow fadeInUp">Let’s Flaunt Some Extraordinary Projects</h2>
            <h1 class="text-center text-grad wow fadeInUp">Together</h1>
            <div class="row">
                <div class="col-md-12 col-xs-12">
                    <div class="contact_home wow fadeInUp">
                        <div class="conform" id="cform">
                            <form class="form-get-quote" action="javascript:;" method="POST">
                                <div class="row">
                                    <div class="col-md-6 col-xs-12">
                                        <div class="field">
                                            <input type="text" class="required" name="quote[name]" placeholder="Name*"
                                                maxlength="70" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xs-12">
                                        <div class="field">
                                            <input type="text" name="quote[email]" class="email required"
                                                placeholder="Email*" maxlength="100" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-xs-12">
                                        <div class="field number">
                                            <input name="quote[phone]" class="required number phoneNum" type="text" placeholder="Phone Number*" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xs-12">
                                        <div class="field">
                                            <select name="quote[service]" class="intrested">
                                                <option value>I am Interested in</option>
                                                <option value="Logo Design">Logo Design</option>
                                                <option value="Brand Development">Brand Development</option>
                                                <option value="Web Design &amp; Development">Web Design &amp;
                                                    Development</option>
                                                <option value="App Design &amp; Development">App Design &amp;
                                                    Development</option>
                                                <option value="Back-End Development">Back-End Development</option>
                                                <option value="Digital Marketing">Digital Marketing</option>
                                                <option value="Marketing Collaterals">Marketing Collaterals</option>
                                                <option value="Motion Graphics">Motion Graphics</option>
                                                <option value="Website Management">Website Management</option>
                                                <option value="Domain Registration">Domain Registration</option>
                                                <option value="Creative Copywriting">Creative Copywriting</option>
                                                <option value="2D &amp; 3D Illustration">2D &amp; 3D Illustration
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 col-xs-12">
                                        <div class="field">
                                            <textarea name="quote[message]" class="required"
                                                placeholder="Any Other Description" maxlength="254" required></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 text-center col-xs-12 agre-buton">
                                        <input type="submit" name="submit" value="Submit"
                                            class="grad-color btn-validate">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div id="SignupModal" class="myFormTheme" role="dialog" tabindex="-1" aria-labelledby="SignupModalLabel"
        style="outline:none;">
        <div class="modal-dialog animated bounceInDown modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <div class="clearfix"></div>
                    <h2>Get 70% Discount</h2>
                    <p class="text-center tagline">fill hout this brief form to get your discount reserved</p>
                </div>
                <div class="modal-body">
                    <div class="conform" id="popupform">
                        <form class="form-get-quote" action="javascript:;" method="POST">
                            <div class="row">
                                <div class="col-md-12 col-xs-12">
                                    <div class="field"><i class="fa fa-user"></i>
                                        <input type="text" class="required" name="quote[name]" placeholder="Name"
                                            maxlength="70" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-xs-12">
                                    <div class="field"><i class="fa fa-envelope"></i>
                                        <input type="text" class="required email" name="quote[email]"
                                            placeholder="Email" maxlength="254" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-xs-12">
                                    <div class="field number" style="width: 100%;"><i class="fa fa-phone"
                                            aria-hidden="true"></i>
                                        <input name="quote[phone]" class="required number phoneNum" type="text"
                                            placeholder="Phone Number" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-xs-12">
                                    <div class="field number" style="width: 100%;"><i class="fa fa-paper-plane" aria-hidden="true"></i>
                                        <textarea name="quote[message]" class="required"
                                                placeholder="Any Other Description" maxlength="254" required></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-xs-12">
                                    <input type="submit" name="submit" value="PROCEED" class="grad-color btn-validate">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="cta">
        <div class="container">
            <h2>Have a project for us? <a href="javascript:;.html" onclick="setButtonURL();"
                    class="order_button"><span>Get in touch</span></a></h2>
            <ul>
                <li class="cta-tollfree first"><a href="tel:<?php  echo $phone;?>"><i class="fa fa-phone"
                            aria-hidden="true"></i> <?php  echo $phone;?></a></li>
                <li class="cta-email"><a href="<?php  echo $email;?>"><i
                            class="fa fa-envelope"></i><?php  echo $email;?></a>
                </li>
                <li><i class="fa fa-map-marker" aria-hidden="true"></i> <?php  echo $address;?>
                </li>
            </ul>
        </div>
    </section>
    <footer>
        <div class="container">
            <ul>
                <li class="first"><a href="https://designcreatic.com/privacy-policy.php">Privacy Policy</a></li>
                <li class="last"><a href="https://designcreatic.com/terms-conditions.php">Terms &amp; Conditions</a></li>
            </ul>
            <p class="diclaimer">Disclaimer: <br>
                Logo, name and graphic representation of <?php  echo $domain;?> and its products and services are trademarked with of <?php  echo $domain;?> . All other company names, trademarks and logos mentioned on this website are the property of their respective owners and do not represent or imply endorsement, sponsorship or recommendation by <?php  echo $domain;?>.
            </p>
        </div>
    </footer>

    <script data-cfasync="false" src="js/cloudflare-static-email-decode.min.js"></script>
    <script data-cfasync="false" src="js/6101-js-jquery-2.1.3.min.js"></script>
    <script data-cfasync="false" defer src="js/3311-js-bootstrap.min.js"></script>
    <script data-cfasync="false" defer src="js/6368-js-wow.min.js"></script>
    <script data-cfasync="false" defer src="js/5607-js-jquery.shuffle.min.js"></script>
    <script data-cfasync="false" defer src="js/1386-js-owl.carousel.min.js"></script>
    <script data-cfasync="false" defer src="js/2241-js-scripts.js"></script>
    <script data-cfasync="false" defer src="js/5569-js-jquery.mCustomScrollbar.concat.min.js"></script>
    <script data-cfasync="false" defer src="js/5626-js-jquery.fancybox.js"></script>
    <script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/jquery.inputmask.bundle.js" type="text/javascript">
    </script>

    <!-- Start of designflithelp Zendesk Widget script -->
    <script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=570ad7cb-9cae-4f57-a404-96abc1cd8b95"> </script>
    <!-- End of designflithelp Zendesk Widget script -->



    <!--<script data-cfasync="false" defer src="js/.-904-custom.js"></script>-->
    <script src="js/5409-js-jquery.inputmask.bundle.js"></script>
    <script type="text/javascript">
    zE(function() {
        $zopim(function() {
            $zopim.livechat.setOnUnreadMsgs(unread);

            function unread(number) {
                if (number >= 1) {
                    $zopim.livechat.window.show();
                }
            }
        });
    });
    window.setTimeout(function() {
        $zopim.livechat.button.show();
        $zopim.livechat.window.show();
        $zopim.livechat.bubble.show();
    }, 1000);
    $(".phoneNum").inputmask({
        "mask": "+9(999) 999-9999"
    }).on("input", function() {
        var minLength = 11; // minimum length of the formatted phone number, including the country code
        var phoneNumber = $(this).val().replace(/\D/g, ''); // remove non-digit characters from the input value
        if (phoneNumber.length < minLength) {
            this.setCustomValidity("Phone number must have a minimum length of " + minLength + " digits");
        } else {
            this.setCustomValidity("");
        }
    });
    $(document).ready(function() {
        // $(".package_detail_zee").val($(".ulzee").html().replace(/(<([^>]+)>)/gi, ""));
        $(".package_detail_zee").val($(".ulzee").html());
        $(".open_modal_zee").click(function() {
            $("#SignupModal").modal();
            if ($(this).attr("data-type") == "movetothankyou") {
                $(".package_detail_2").val("");
                $(".package_name_2").val("");
                $(".package_price_2").val("");
                $(".service_type_2").val($(this).attr("data-type"));
            } else {
                $(".package_name_2").val($(this).attr("data-name"));
                $(".package_price_2").val($(this).attr("data-price"));
                $(".service_type_2").val($(this).attr("data-type"));
                $(".package_detail_2").val($(this).closest("div").find(".getul").html().replace(
                    /(<([^>]+)>)/gi, ""));
            }
        });
    });
    </script>
    <script>
    $(window).load(function() {
        var reverseLogoCard = true;
        var lastLogoCardIndex = -1;
        $('.logo-card .back').show();
        $('.logo-card').data('reverseLogoCard', reverseLogoCard).flip({
            trigger: 'manual',
            reverse: reverseLogoCard
        });

        function flipLogoCard() {
            var max = $('.logo-card').length;
            if ($('body').width() < 551) max = 6;
            var index = Math.floor(Math.random() * max);
            if (index == lastLogoCardIndex) {
                index = Math.floor(Math.random() * max);
            }
            lastLogoCardIndex = index;
            var wait = Math.random() * 1000 * Math.floor(Math.random() * 4) + 750;
            var card = $('.logo-card').eq(index);
            reverseLogoCard = card.data('reverseLogoCard') ? false : true;
            card.data('reverseLogoCard', reverseLogoCard);
            card.flip('toggle', function() {
                card.flip({
                    reverse: reverseLogoCard
                });
                setTimeout(function() {
                    flipLogoCard();
                }, wait);
            });
        }
        setTimeout(function() {
            flipLogoCard();
        }, 1000);
    });
    </script>
    <script type="text/javascript">
    function order_now_value(x, y, desc) {
        console.log(desc);
        document.getElementById('lead_area_price').value = x;
        document.getElementById('lead_area').value = y;
        document.getElementById('desc').value = desc;
    }

    function vidplay() {
        var video = document.getElementById("videoPlayer");
        var button = document.getElementById("playbtn");
        if (video.paused) {
            video.play();
            button.className = "pause"
        } else {
            video.pause();
            button.className = "play"
        }
    }
    </script>
    <script>
    $(document).on('click', '.new-custom-close', function() {
        $('#modal').hide();
    });

    var check = true;
    $("body").mouseleave(function() {
        if (check) {
            $(".custom-modal").css("display", "block");
            $("#modal").show();
            check = false;
        };
    });
    </script>

    <script>
    $('.form-get-quote').on('submit', function(e) {
        //$('.btn-quote').on('click' , function(e){        
        var obj = $(this);
        e.preventDefault();
        var data = $(obj).serialize();
        jQuery.ajax({
            url: "sendmail.php",
            // For Demo
            // url: window.location.origin + '/lvm-track-html/v6/sendmail.php',
            // For Live
            // url: window.location.origin + '/sendmail.php',
            type: "POST",
            data: data,
            async: false, // Has to be false to be able to return response
            dataType: "json", // Has to be false to be able to return response
            success: function(response) {
                if (response.status == 1) {
                    // $('#myModal').modal('hide');
                    // $('#myModal').modal('show');
                    // alert('Submit Successfully.');
                    window.location = "/thankyou.php";
                    obj.trigger("reset");
                } else {
                    return false;
                }
            },
            beforeSend: function() {
                // Loader.show();
            }
        });
        return false;
    });
    </script>
</body>

</html>