<?php

$servername = "localhost";
$username = "desiemfu_creatic";
$password = "VBke*eAU4uLd";
$db = "desiemfu_creatic";

$conn = new mysqli($servername, $username, $password , $db);

if ((isset($_POST['inquiry'])) || (isset($_POST['quote'])))  {

$body_att = 'colspan="2" align="left" style="background-color:#000;color:#E84704;text-align: center;"';
$body_att1 = 'colspan="2" align="left" style="background-color:#57585B;color:#fff;"';

// Get data
$data = (isset($_POST['inquiry'])) ? $_POST['inquiry'] : $_POST['quote'];

        $special_offer = 'special_offer';
            $data_value = json_encode($data);
        	$sql = "INSERT INTO leads(page_name,leads)
            VALUES('$special_offer','$data_value')";
            if ($conn->query($sql) === TRUE) {
            //return "true";
          }else{
             // return "false";
          }
      

// $data['ip'] = $_SERVER["REMOTE_ADDR"];

$data ['Link'] = "http://$_SERVER[HTTP_HOST]$_SERVER[DOCUMENT_URL]";

// Set template

// Client email
$to = "info@designcreatic.com";

$subject = (isset($_POST['inquiry'])) ? "Inquiry - Form Alert" : "Quote - Form";


// echo $file;
// exit;
//echo "file moved";
//exit;
$inputs = '';
foreach ($data as $key => $value) {
	$inputs .= "<tr>
			<td width='14%' align='left'>".$key."</td>
			<td width='14%' align='left'>" . $value . "</td>
		</tr>";
}

$message = "
<html>
<head>
<title>Inquiry - Form</title>
</head>
<body>

<div style='margin-top:-10px'>
		<table width='70%' border='1' cellpadding='6' cellspacing='5' style='font-family:Verdana;font-size:12px; border-collapse:collapse'>
			<tr>
				<td border='0' colspan='2' " . $body_att . ">
				// 	<img src='https://www.designcreatic.com/images/logo.png' width='190' />
				</td>
			</tr>

		".$inputs."
		</table>
	</div>";

  
	
$message.= "</body></html>";


// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: Design Creatic <leads@designcreatic.com>' . "\r\n";
$headers .= 'Cc: leads@designcreatic.com' . "\r\n";

if(mail($to,$subject,$message,$headers)){
   // echo "1";
	$parm['status'] = 1;
   echo json_encode($parm);
}
else{
    $parm['status'] = 0;
    echo json_encode($parm);
}
}

?>