    // Form quote start
      $('.form-get-quote').on('submit' , function(e){
          
        // alert($('#getasdasd').val());
        // str.replace("Microsoft", "W3Schools");
        //$('.btn-quote').on('click' , function(e){  
        var phone = $(this).find('.phoneNum').val();
        
        phone  = phone.replace("(", "");
        phone  = phone.replace(")", "");
        phone  = phone.replace("-", "");
        phone  = phone.replace(" ", "");
        phone  = phone.replace("_", "");
        
        
        
        if(phone.length == 12){
        }
        else{
            alert('invalid Phone Number');
            return false;
        }
        console.log(phone);
        
        var obj = $(this);
        e.preventDefault();
        var data = $(obj).serialize();
         jQuery.ajax({
                url: "sendmail",
                // For Demo
                //url: window.location.origin + '/lvm-track-html/v6/sendmail.php',
                // For Live
                //url: window.location.origin + '/sendmail.php',
                type: "POST",
                data: data,
                async: false,  // Has to be false to be able to return response
                dataType: "json",  // Has to be false to be able to return response
                success: function(response) {
                    if (response.status == 1) {
                      //$('#myModal').modal('hide');
                      //$('#myModal').modal('show');
                      window.location = "https://logofication.com/thank_you";
                      obj.trigger("reset"); 
                    }
                    else{
                      return false;
                    }
                    
                },
                beforeSend: function()
                {
                    // Loader.show();
                }
            }); 
            
            return false;
    });
    // Form quote end